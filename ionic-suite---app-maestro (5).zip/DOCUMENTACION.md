# Documentación Técnica Completa del Proyecto Applet Mobile Ionic & React

> **Sistema Multi-Catálogo y Gestión Móvil con Ionic Framework, React y TypeScript**

---

## 1. Resumen Ejecutivo

El presente proyecto es una aplicación web y móvil progresiva (PWA / Cross-Platform Architecture) construida sobre **React 18**, **TypeScript**, **Ionic UI Web Components** y **Tailwind CSS / SCSS**. 

El sistema integra cuatro aplicaciones o catálogos independientes dentro de una experiencia de usuario móvil unificada (*Mobile App Shell*), permitiendo cambiar de módulo de forma limpia mediante una barra de navegación inferior (*Bottom Navigation Bar*) y un menú lateral de hamburguesa (*Ionic Side Menu*):

1. **Catálogo de Libros (Book Catalog)**: Gestión de biblioteca, filtrado por género, calificación por estrellas, marcado de favoritos y visualización detallada de sinopsis y disponibilidad.
2. **Catálogo de Restaurantes (Restaurant Catalog)**: Guía gastronómica con filtrado por tipo de cocina (Mariscos, Italiana, Mexicana, Cafés, Internacional, Cortes), mapa de dirección, teléfono de reserva y modal interactivo de detalle.
3. **Catálogo de Recetas (Recipe Catalog)**: Recetario interactivo con tiempo de preparación en minutos, nivel de dificultad, conteo calórico, ingredientes dinámicos, pasos detallados y formulario reactivo con validaciones para agregar nuevas recetas.
4. **Buzón de Sugerencias (Suggestion Box)**: Sistema de retroalimentación en tiempo real con categorías de comentarios, niveles de prioridad, estados de resolución y formulario modal reactivo.

---

## 2. Arquitectura del Sistema

La arquitectura sigue el patrón **Modular Component-Service Pattern** optimizado para aplicaciones SPA (*Single Page Application*) y PWA cross-platform con simulación Ionic Standalone:

```
+-----------------------------------------------------------------------+
|                            App.tsx (Root)                             |
+-----------------------------------------------------------------------+
                                   |
                     +-------------v-------------+
                     |       MobileFrame         |
                     |  (Ionic Menu + Tabs Shell)|
                     +-------------+-------------+
                                   |
   +-------------------------------+-------------------------------+
   |                               |                               |
+--v-----------------+   +---------v----------+   +----------------v---+
|  Books Module      |   | Restaurants Module |   | Recipes Module     |
| - BooksHomePage    |   | - RestaurantsHome  |   | - RecipesHomePage  |
| - BookDetailPage   |   | - RestDetailModal  |   | - RecipeDetailPage |
+--------------------+   +--------------------+   +--------------------+
                                   |
                         +---------v----------+
                         | Suggestions Module |
                         | - SuggestionsHome  |
                         | - NewSuggestModal  |
                         +--------------------+
                                   |
         +-------------------------v-------------------------+
         |                 Data Persistence Layer            |
         | (BookService, RestaurantService, RecipeService,   |
         |  SuggestionService via LocalStorage & Initial Seed) |
         +---------------------------------------------------+
```

### Principios Clave de Diseño:
- **Standalone Architecture**: Componentes independientes tipo React Functional Components sin acoplamiento a módulos pesados de terceros.
- **Capa de Servicios con Persistencia**: Los servicios operan con un almacenamiento `LocalStorage` persistente, inicializándose automáticamente con semillas (*seeders*) si no existen registros.
- **Compatibilidad Extensible de Interfaces**: Los modelos de datos cuentan con campos duales (`favorite` e `isFavorite`, `name` y `title`, `minutes` y `prepTime`) para mantener 100% de compatibilidad con especificaciones de APIs REST, interfaces Ionic o requerimientos heredados.
- **Ionic Web Components Wrappers**: Contenedores semánticos (`src/components/shared/IonicUI.tsx`) que imitan de forma nativa los componentes `<ion-header>`, `<ion-toolbar>`, `<ion-content>`, `<ion-card>`, `<ion-button>`, `<ion-modal>`, `<ion-toast>` y `<ion-fab>`.

---

## 3. Árbol de Carpetas Completo

```
.
├── index.html
├── metadata.json
├── package.json
├── tsconfig.json
├── tsconfig.node.json
├── vite.config.ts
├── public/
│   └── favicon.ico
└── src/
    ├── App.tsx
    ├── main.tsx
    ├── index.css
    ├── components/
    │   └── shared/
    │       ├── IonicUI.tsx
    │       └── MobileFrame.tsx
    ├── environments/
    │   └── environment.ts
    ├── interfaces/
    │   └── common.interface.ts
    ├── models/
    │   ├── book.model.ts
    │   ├── recipe.model.ts
    │   ├── restaurant.model.ts
    │   └── suggestion.model.ts
    ├── pages/
    │   ├── books/
    │   │   ├── BookDetailPage.tsx
    │   │   └── BooksHomePage.tsx
    │   ├── recipes/
    │   │   ├── RecipeDetailPage.tsx
    │   │   └── RecipesHomePage.tsx
    │   ├── restaurants/
    │   │   ├── RestaurantDetailModal.tsx
    │   │   └── RestaurantsHomePage.tsx
    │   └── suggestions/
    │       ├── NewSuggestionModal.tsx
    │       └── SuggestionsHomePage.tsx
    ├── services/
    │   ├── book.service.ts
    │   ├── recipe.service.ts
    │   ├── restaurant.service.ts
    │   └── suggestion.service.ts
    └── theme/
        └── ionic-theme.css
```

---

## 4. Tecnologías Utilizadas

| Tecnología / Librería | Versión | Propósito en el Proyecto |
| :--- | :--- | :--- |
| **React** | `^18.3.1` | Librería principal para la construcción de interfaces de usuario reactivas. |
| **TypeScript** | `^5.5.3` | Tipado estático riguroso, interfaces, enums y seguridad de tipos. |
| **Vite** | `^5.4.2` | Bundler y servidor de desarrollo ultra rápido con soporte HMR. |
| **Ionic UI Web Design System** | Custom / Ionic Spec | Estilos visuales, tokens CSS y wrappers semánticos nativos de Ionic (`ion-card`, `ion-button`, `ion-modal`, etc.). |
| **Tailwind CSS** | `^4.0.0` | Framework de utilidades CSS para diseño responsive, grillas adaptables y tipografía. |
| **Lucide React** | `^0.344.0` | Conjunto de íconos vectoriales modernos de alta visibilidad. |
| **LocalStorage Web API** | Nativa | Persistencia local de datos del usuario (favoritos, libros añadidos, nuevas recetas, etc.). |

---

## 5. Explicación de Modelos (`src/models/`)

### 5.1 `book.model.ts`
Define la entidad de un libro dentro de la biblioteca digital:
```typescript
export interface Book {
  id: string;
  title: string;
  author: string;
  genre: 'Ficción' | 'No Ficción' | 'Ciencia Ficción' | 'Misterio' | 'Romance' | 'Desarrollo Personal';
  rating: number; // 1 a 5
  isFavorite: boolean;
  coverUrl: string;
  synopsis: string;
  pages: number;
  publishedYear: number;
}
```

### 5.2 `restaurant.model.ts`
Define la entidad de restaurante dentro del catálogo gastronómico:
```typescript
export interface Restaurant {
  id: string;
  name: string;
  category: 'Mariscos' | 'Italiana' | 'Mexicana' | 'Cafés' | 'Internacional' | 'Cortes';
  rating: number;
  favorite: boolean;     // Propiedad primaria requerida por especificación
  isFavorite?: boolean;  // Aliased para compatibilidad interna
  address: string;
  phone: string;
  imageUrl: string;
  description: string;
  priceRange: '$' | '$$' | '$$$' | '$$$$';
}
```

### 5.3 `recipe.model.ts`
Define la estructura completa de una receta de cocina:
```typescript
export interface Recipe {
  id: string;
  name: string;         // Propiedad primaria
  title: string;        // Compatibilidad de título
  category: 'Desayunos' | 'Almuerzos' | 'Cenas' | 'Postres' | 'Bebidas' | 'Ensaladas';
  minutes: number;      // Tiempo en minutos (requerido por especificación)
  prepTime: number;     // Alias de tiempo de preparación
  favorite: boolean;    // Estado de favorito
  isFavorite: boolean;  // Compatibilidad
  ingredients: string[];
  instructions: string[];
  servings: number;
  difficulty: 'Fácil' | 'Media' | 'Avanzada';
  calories: number;
  imageUrl: string;
  createdAt: string;
}
```

### 5.4 `suggestion.model.ts`
Define las sugerencias enviadas por usuarios en el buzón:
```typescript
export interface Suggestion {
  id: string;
  title: string;
  category: 'Sugerencia' | 'Queja' | 'Felicitación' | 'Mejora de Servicio';
  description: string;
  userEmail: string;
  status: 'Pendiente' | 'En Revisión' | 'Atendido';
  priority: 'Baja' | 'Media' | 'Alta';
  createdAt: string;
}
```

---

## 6. Explicación de Servicios (`src/services/`)

Cada servicio implementa el patrón de acceso a datos (*Data Access Service*) con respaldo en `window.localStorage`.

### 6.1 `book.service.ts`
- **`getAll()`**: Retorna la lista completa de libros almacenados.
- **`getById(id)`**: Busca y retorna un libro por su `id`.
- **`getFavorites()`**: Filtra los libros marcados como favoritos.
- **`toggleFavorite(id)`**: Invierte el estado de favorito de un libro y actualiza `localStorage`.
- **`add(bookData)`**: Crea y persiste un nuevo libro.
- **`delete(id)`**: Elimina un libro del catálogo.
- **`resetToDefaults()`**: Restablece los datos a las semillas iniciales.

### 6.2 `restaurant.service.ts`
- **`getAll()`**: Obtiene la lista completa de restaurantes.
- **`getById(id)`**: Obtiene un restaurante específico.
- **`getFavorites()`**: Retorna restaurantes donde `favorite` o `isFavorite` sea `true`.
- **`toggleFavorite(id)`**: Alterna sincrónicamente los campos `favorite` e `isFavorite`.
- **`add(restaurantData)`**: Agrega un nuevo restaurante al catálogo con ID generado automáticamente.
- **`resetToDefaults()`**: Carga el catálogo original de restaurantes.

### 6.3 `recipe.service.ts`
- **`getAll()`**: Retorna todas las recetas.
- **`getById(id)`**: Busca una receta por su identificador.
- **`getFavorites()`**: Filtra recetas donde `favorite || isFavorite` sea `true`.
- **`toggleFavorite(id)`**: Cambia el estado de favorito y guarda cambios.
- **`add(recipeData)`**: Agrega una receta mapeando sincrónicamente `name`/`title` y `minutes`/`prepTime`.
- **`delete(id)`**: Elimina una receta.
- **`resetToDefaults()`**: Restablece el recetario original.

### 6.4 `suggestion.service.ts`
- **`getAll()`**: Obtiene todas las sugerencias recibidas.
- **`getById(id)`**: Retorna una sugerencia por ID.
- **`add(suggestionData)`**: Registra una nueva sugerencia con estado inicial `'Pendiente'`.
- **`updateStatus(id, status)`**: Actualiza el estado de atención de la sugerencia.
- **`resetToDefaults()`**: Restablece el buzón inicial.

---

## 7. Explicación de Componentes Compartidos

### 7.1 `src/components/shared/IonicUI.tsx`
Encapsula la jerarquía de UI de Ionic utilizando clases CSS optimizadas, animaciones de transición y accesibilidad:
- **`IonHeader` / `IonToolbar` / `IonTitle`**: Encabezado superior semántico con soporte para botones laterales (`IonButtons`).
- **`IonContent`**: Área principal de desplazamiento con scroll fluido y fondo configurable.
- **`IonCard`**: Tarjetas elevadas con bordes suaves, efectos de hover y soporte para imágenes superiores.
- **`IonButton`**: Botón con variantes de color (`primary`, `secondary`, `success`, `danger`, `outline`, `clear`) y tamaños.
- **`IonFab`**: Botón de acción flotante (*Floating Action Button*) fijado en la esquina inferior derecha.
- **`IonBadge`**: Etiqueta/píldora distintiva para estados o categorías.
- **`IonModal`**: Ventana emergente modal con backdrop difuminado y botón de cierre.
- **`IonToast`**: Notificación flotante temporal en la parte inferior para confirmaciones de usuario.

### 7.2 `src/components/shared/MobileFrame.tsx`
Componente principal que envuelve el *Shell* de la aplicación:
- **Mobile Container**: Renderiza un marco movilizado con diseño responsive que se adapta elegantemente desde pantallas de smartphone hasta escritorio.
- **Menú Lateral Ionic (`IonMenu`)**: Menú desplegable tipo *Drawer* con accesos rápidos a los 4 catálogos, contador total de ítems por categoría y opción de restablecer datos.
- **Bottom Navigation Tabs**: Barra de pestañas fijada en la parte inferior con indicadores activos para conmutar entre **Libros**, **Restaurantes**, **Recetas** y **Sugerencias**.

---

## 8. Explicación de Páginas por Módulo

### 8.1 Módulo de Libros
- **`BooksHomePage.tsx`**: Muestra la cuadrícula (*grid*) responsive de libros, barra de búsqueda en tiempo real, filtro por género, botón para agregar nuevo libro mediante un modal con validación y acción de favorito instantánea.
- **`BookDetailPage.tsx`**: Vista extendida del libro seleccionado con carátula a alta resolución, autor, calificación en estrellas, sinopsis completa, detalles de edición y opciones para marcar favorito o eliminar.

### 8.2 Módulo de Restaurantes
- **`RestaurantsHomePage.tsx`**: Muestra las tarjetas de los restaurantes con calificación, dirección, categoría gastronómica, indicador de rango de precios y botón flotante FAB para agregar restaurantes.
- **`RestaurantDetailModal.tsx`**: Modal desplegable con mapa de dirección simulado, teléfono de contacto directo, descripción de especialidades, insignia de categoría y botón de favorito.

### 8.3 Módulo de Recetas
- **`RecipesHomePage.tsx`**: Muestra las recetas con insignias de dificultad, tiempo de preparación en minutos (`minutes`), calorías por porción e íconos de interacción. Incluye un modal reactivo para la creación de nuevas recetas con lista dinámica de ingredientes y pasos de preparación.
- **`RecipeDetailPage.tsx`**: Vista de detalle con encabezado de imagen a pantalla completa, lista de ingredientes con checkboxes interactivos y guía paso a paso numerada para la cocina.

### 8.4 Módulo de Sugerencias
- **`SuggestionsHomePage.tsx`**: Dashboard con métricas de sugerencias (Pendientes, En Revisión, Atendidas), listado de sugerencias recibidas con filtros por prioridad y categoría, y cambio rápido de estado.
- **`NewSuggestionModal.tsx`**: Formulario reactivo para el envío de sugerencias con campos validados de título, categoría, nivel de prioridad, correo electrónico y descripción detallada.

---

## 9. Flujo de Navegación y Rutas del Sistema

Dado que el applet se ejecuta en una arquitectura Standalone SPA nativa en React, la navegación se gestiona mediante estado reactivo centralizado en `App.tsx`:

```
               [ APPLICACIÓN PRINCIPAL (App.tsx) ]
                                |
        +-----------------------+-----------------------+
        |                       |                       |
   (Pestaña 1)             (Pestaña 2)             (Pestaña 3)             (Pestaña 4)
  [  Libros  ]           [Restaurantes]           [  Recetas ]           [Sugerencias]
        |                       |                       |                       |
   +----+----+             +----+----+             +----+----+             +----+----+
   |         |             |         |             |         |             |         |
[Home]   [Detalle]      [Home]    [Modal]       [Home]   [Detalle]      [Home]    [Modal]
```

### Reglas de Navegación:
- Cambiar de pestaña en las **Bottom Tabs** borra los identificadores seleccionados (`selectedBookId` / `selectedRecipeId`), retornando siempre a la vista principal de esa categoría.
- Al hacer clic en una tarjeta de libro o receta, se activa la vista de detalle correspondiente (`BookDetailPage` / `RecipeDetailPage`).
- El botón de regreso (`← Regresar`) restablece el ID a `null` de forma inmediata.
- Las ventanas modales (Restaurante Detalle, Nueva Sugerencia, Agregar Libro, Agregar Receta) se superponen con animaciones CSS nativas.

---

## 10. Formularios Reactivos y Validaciones

Cada pantalla de creación implementa validación de datos en tiempo real antes de llamar al servicio correspondiente:

### Ejemplo de Reglas de Validación Aplicadas:
1. **Campos Obligatorios**:
   - `nombre` / `titulo`: Mínimo 3 caracteres, no vacío.
   - `categoría`: Selección requerida dentro de las opciones predefinidas.
   - `descripción` / `sinopsis`: Mínimo 10 caracteres.
   - `correo electrónico` (en sugerencias): Formato válido de e-mail mediante expresión regular (`/^[^\s@]+@[^\s@]+\.[^\s@]+$/`).
2. **Validaciones Numéricas**:
   - `minutos` / `prepTime`: Valor numérico positivo mayor a 0.
   - `páginas`: Entero positivo mayor a 0.
   - `calificación`: Valor entre 1.0 y 5.0.

---

## 11. Manual de Instalación, Ejecución y Compilación

### 11.1 Requisitos Previos
- **Node.js**: Versión `18.0.0` o superior.
- **npm**: Versión `9.0.0` o superior.
- **Ionic CLI** (Opcional para CLI nativa): `npm install -g @ionic/cli`

### 11.2 Instalación de Dependencias
Abre una terminal en la raíz del proyecto y ejecuta:
```bash
npm install
```

### 11.3 Ejecución en Modo Desarrollo
Para iniciar el servidor de desarrollo local con recarga en vivo:
```bash
# Opción 1: Mediante npm/vite
npm run dev

# Opción 2: Mediante Ionic CLI
ionic serve
```
La aplicación estará disponible en `http://localhost:3000` (o el puerto asignado).

### 11.4 Verificación de Código y Linting
Para verificar la integridad de tipos en TypeScript sin errores de compilación:
```bash
npm run lint
```

### 11.5 Compilación para Producción
Para generar el paquete compilado listo para despliegue:
```bash
# Mediante Vite
npm run build

# O mediante Ionic CLI
ionic build
```
Los archivos optimizados y minificados se generarán en la carpeta `dist/`.

---

## 12. Requisitos de Sistema y Entorno

- **Sistema Operativo**: Windows 10/11, macOS 12+, Linux (Ubuntu 20.04+).
- **Navegadores Soportados**: Google Chrome 100+, Mozilla Firefox 100+, Safari 15+, Microsoft Edge 100+.
- **Resolución Mínima**: 320px (Mobile First) hasta 4K Ultrawide (Desktop Adaptive Grid).

---

## 13. Posibles Mejoras Futuras

1. **Backend Persistente con Firebase / Cloud SQL**: Reemplazar la capa de `LocalStorage` por sincronización en tiempo real utilizando Firestore o Cloud SQL con Prisma/Drizzle ORM.
2. **Autenticación de Usuarios**: Agregar inicio de sesión mediante OAuth 2.0 (Google Workspace) para personalización de favoritos por usuario.
3. **Soporte PWA Offline**: Registrar un *Service Worker* con estrategia de caché *Stale-While-Revalidate* para funcionamiento 100% fuera de línea.
4. **Modo Oscuro Dinámico**: Incorporar un selector de tema claro/oscuro extendiendo los tokens de CSS en `:root` y `.dark`.

---

*Documento técnico generado automáticamente listo para exportar a PDF, HTML o Microsoft Word.*
