import React from 'react';
import { Inbox, Search, Heart, AlertTriangle } from 'lucide-react';

interface EmptyStateProps {
  type?: 'empty' | 'search' | 'favorites' | 'error';
  title?: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  type = 'empty',
  title,
  description,
  actionLabel,
  onAction,
  className = ''
}) => {
  const getIcon = () => {
    switch (type) {
      case 'search':
        return <Search className="w-8 h-8 text-blue-500" />;
      case 'favorites':
        return <Heart className="w-8 h-8 text-rose-500" />;
      case 'error':
        return <AlertTriangle className="w-8 h-8 text-amber-500" />;
      default:
        return <Inbox className="w-8 h-8 text-gray-400" />;
    }
  };

  const defaultTitles = {
    empty: 'Sin registros disponibles',
    search: 'No se encontraron resultados',
    favorites: 'Aún no tienes favoritos',
    error: 'Ocurrió un problema al cargar'
  };

  const defaultDescriptions = {
    empty: 'No hay elementos guardados en este catálogo por el momento.',
    search: 'Prueba cambiando los términos de búsqueda o limpiando los filtros seleccionados.',
    favorites: 'Haz clic en el ícono de corazón en cualquier tarjeta para guardarlo aquí.',
    error: 'Por favor intenta recargar la página o verificar los filtros aplicados.'
  };

  return (
    <div className={`flex flex-col items-center justify-center p-8 text-center bg-white/70 backdrop-blur-sm rounded-2xl border border-gray-100 shadow-sm ${className}`}>
      <div className="w-16 h-16 rounded-2xl bg-gray-50 flex items-center justify-center border border-gray-100 mb-4 shadow-xs">
        {getIcon()}
      </div>

      <h3 className="text-base font-bold text-gray-900 mb-1">
        {title || defaultTitles[type]}
      </h3>

      <p className="text-xs text-gray-500 max-w-sm mb-5 leading-relaxed">
        {description || defaultDescriptions[type]}
      </p>

      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-sm transition-all hover:shadow cursor-pointer active:scale-95"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
};
