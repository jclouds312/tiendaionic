import React, { useState, useEffect } from 'react';
import { 
  ChevronLeft, 
  X, 
  Check, 
  AlertCircle, 
  Info, 
  Trash2, 
  SlidersHorizontal,
  ChevronRight,
  Star
} from 'lucide-react';

/* -------------------------------------------------------------------------- */
/* ION HEADER & TOOLBAR                                                       */
/* -------------------------------------------------------------------------- */
export const IonHeader: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <header className={`sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-2xs text-gray-900 ${className}`}>
    {children}
  </header>
);

export const IonToolbar: React.FC<{ children: React.ReactNode; color?: string; className?: string }> = ({ children, color, className = '' }) => {
  const colorBg = color === 'primary' 
    ? 'bg-blue-600 text-white' 
    : color === 'success' 
    ? 'bg-emerald-600 text-white' 
    : color === 'danger' 
    ? 'bg-rose-600 text-white'
    : 'bg-white text-gray-900 border-b border-gray-100';

  return (
    <div className={`px-4 py-3 flex items-center justify-between min-h-[52px] gap-2 ${colorBg} ${className}`}>
      {children}
    </div>
  );
};

export const IonTitle: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <h1 className={`font-bold text-base md:text-lg tracking-tight truncate flex-1 text-inherit ${className}`}>
    {children}
  </h1>
);

export const IonButtons: React.FC<{ slot?: 'start' | 'end'; children: React.ReactNode; className?: string }> = ({ slot = 'start', children, className = '' }) => (
  <div className={`flex items-center gap-1.5 ${slot === 'end' ? 'ml-auto' : 'mr-auto'} ${className}`}>
    {children}
  </div>
);

export const IonButton: React.FC<{
  children: React.ReactNode;
  onClick?: () => void;
  fill?: 'clear' | 'outline' | 'solid';
  color?: 'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'medium' | 'light';
  size?: 'small' | 'default' | 'large';
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
  className?: string;
  id?: string;
}> = ({ children, onClick, fill = 'solid', color = 'primary', size = 'default', disabled = false, type = 'button', className = '', id }) => {
  let baseColor = 'bg-blue-600 text-white hover:bg-blue-700 active:bg-blue-800 shadow-2xs';
  if (color === 'secondary') baseColor = 'bg-gray-900 text-white hover:bg-gray-800';
  if (color === 'success') baseColor = 'bg-emerald-600 text-white hover:bg-emerald-700';
  if (color === 'danger') baseColor = 'bg-rose-600 text-white hover:bg-rose-700';
  if (color === 'warning') baseColor = 'bg-amber-500 text-gray-900 hover:bg-amber-600';
  if (color === 'medium') baseColor = 'bg-gray-600 text-white hover:bg-gray-700';
  if (color === 'light') baseColor = 'bg-gray-100 text-gray-800 hover:bg-gray-200 border border-gray-200';

  if (fill === 'clear') {
    if (color === 'primary') baseColor = 'bg-transparent text-blue-600 hover:bg-blue-50';
    else if (color === 'danger') baseColor = 'bg-transparent text-rose-600 hover:bg-rose-50';
    else if (color === 'success') baseColor = 'bg-transparent text-emerald-600 hover:bg-emerald-50';
    else baseColor = 'bg-transparent text-gray-700 hover:bg-gray-100';
  } else if (fill === 'outline') {
    if (color === 'primary') baseColor = 'border border-blue-600 text-blue-600 bg-transparent hover:bg-blue-50';
    else if (color === 'danger') baseColor = 'border border-rose-600 text-rose-600 bg-transparent hover:bg-rose-50';
    else baseColor = 'border border-gray-300 text-gray-700 bg-transparent hover:bg-gray-50';
  }

  let sizePadding = 'px-3.5 py-2 text-xs md:text-sm';
  if (size === 'small') sizePadding = 'px-2.5 py-1 text-xs';
  if (size === 'large') sizePadding = 'px-5 py-2.5 text-base font-semibold';

  return (
    <button
      id={id}
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center justify-center font-medium rounded-md transition-all focus:outline-hidden focus:ring-2 focus:ring-blue-500/30 active:scale-98 disabled:opacity-50 disabled:pointer-events-none cursor-pointer ${baseColor} ${sizePadding} ${className}`}
    >
      {children}
    </button>
  );
};

export const IonBackButton: React.FC<{ onClick?: () => void; text?: string; className?: string }> = ({ onClick, text = 'Atrás', className = '' }) => (
  <button
    type="button"
    onClick={onClick}
    className={`inline-flex items-center gap-1 text-blue-600 hover:text-blue-700 font-medium text-xs md:text-sm py-1 px-2 rounded hover:bg-blue-50 transition-colors cursor-pointer ${className}`}
  >
    <ChevronLeft className="w-4 h-4 md:w-5 md:h-5" />
    <span>{text}</span>
  </button>
);

/* -------------------------------------------------------------------------- */
/* CARDS & CONTAINERS                                                         */
/* -------------------------------------------------------------------------- */
export const IonCard: React.FC<{ children: React.ReactNode; className?: string; onClick?: () => void }> = ({ children, className = '', onClick }) => (
  <div 
    onClick={onClick}
    className={`bg-white rounded-xl border border-gray-200 shadow-2xs hover:shadow-xs transition-all overflow-hidden ${onClick ? 'cursor-pointer active:scale-[0.995]' : ''} ${className}`}
  >
    {children}
  </div>
);

export const IonCardHeader: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <div className={`p-4 pb-2 ${className}`}>{children}</div>
);

export const IonCardTitle: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <h2 className={`font-bold text-base text-gray-900 tracking-tight leading-snug ${className}`}>{children}</h2>
);

export const IonCardSubtitle: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <p className={`text-[10px] font-bold uppercase tracking-widest text-gray-400 mt-0.5 ${className}`}>{children}</p>
);

export const IonCardContent: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <div className={`px-4 pb-4 pt-1 text-xs md:text-sm text-gray-600 leading-relaxed ${className}`}>{children}</div>
);

/* -------------------------------------------------------------------------- */
/* SEGMENT & TABS                                                             */
/* -------------------------------------------------------------------------- */
export const IonSegment: React.FC<{ value: string; onIonChange: (val: string) => void; children: React.ReactNode; className?: string }> = ({ value, onIonChange, children, className = '' }) => {
  return (
    <div className={`bg-gray-100 p-1 rounded-lg flex items-center gap-1 overflow-x-auto no-scrollbar border border-gray-200/80 ${className}`}>
      {React.Children.map(children, (child) => {
        if (React.isValidElement<IonSegmentButtonProps>(child)) {
          return React.cloneElement(child, {
            active: child.props.value === value,
            onClick: () => onIonChange(child.props.value)
          });
        }
        return child;
      })}
    </div>
  );
};

export interface IonSegmentButtonProps {
  value: string;
  children: React.ReactNode;
  active?: boolean;
  onClick?: () => void;
  className?: string;
}

export const IonSegmentButton: React.FC<IonSegmentButtonProps> = ({ children, active, onClick, className = '' }) => (
  <button
    type="button"
    onClick={onClick}
    className={`flex-1 min-w-[75px] py-1 px-2.5 text-xs font-medium rounded-md transition-all whitespace-nowrap cursor-pointer text-center ${
      active
        ? 'bg-white text-blue-600 shadow-2xs font-bold'
        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-200/50'
    } ${className}`}
  >
    {children}
  </button>
);

/* -------------------------------------------------------------------------- */
/* LIST & ITEMS                                                               */
/* -------------------------------------------------------------------------- */
export const IonList: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <div className={`bg-white rounded-xl border border-gray-200 divide-y divide-gray-100 overflow-hidden shadow-2xs ${className}`}>
    {children}
  </div>
);

export const IonItem: React.FC<{ children: React.ReactNode; onClick?: () => void; className?: string }> = ({ children, onClick, className = '' }) => (
  <div 
    onClick={onClick}
    className={`px-4 py-3 flex items-center gap-3 transition-colors ${onClick ? 'hover:bg-gray-50 cursor-pointer active:bg-gray-100' : ''} ${className}`}
  >
    {children}
  </div>
);

export const IonLabel: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <div className={`flex-1 min-w-0 ${className}`}>{children}</div>
);

export const IonBadge: React.FC<{ 
  children: React.ReactNode; 
  color?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'medium';
  className?: string; 
}> = ({ children, color = 'primary', className = '' }) => {
  let badgeStyle = 'bg-blue-50 text-blue-700 border border-blue-200';
  if (color === 'secondary') badgeStyle = 'bg-gray-100 text-gray-800 border border-gray-200';
  if (color === 'success') badgeStyle = 'bg-emerald-50 text-emerald-700 border border-emerald-200';
  if (color === 'warning') badgeStyle = 'bg-amber-50 text-amber-800 border border-amber-200';
  if (color === 'danger') badgeStyle = 'bg-rose-50 text-rose-700 border border-rose-200';
  if (color === 'medium') badgeStyle = 'bg-gray-50 text-gray-600 border border-gray-200';

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium font-mono ${badgeStyle} ${className}`}>
      {children}
    </span>
  );
};

/* -------------------------------------------------------------------------- */
/* FAB & FLOATING BUTTONS                                                     */
/* -------------------------------------------------------------------------- */
export const IonFab: React.FC<{ vertical?: 'top' | 'bottom'; horizontal?: 'start' | 'end' | 'center'; children: React.ReactNode }> = ({ vertical = 'bottom', horizontal = 'end', children }) => {
  const vertClass = vertical === 'top' ? 'top-20' : 'bottom-6';
  const horizClass = horizontal === 'start' ? 'left-6' : horizontal === 'center' ? 'left-1/2 -translate-x-1/2' : 'right-6';

  return (
    <div className={`fixed ${vertClass} ${horizClass} z-40 pointer-events-auto`}>
      {children}
    </div>
  );
};

export const IonFabButton: React.FC<{ children: React.ReactNode; onClick?: () => void; color?: string; className?: string }> = ({ children, onClick, color = 'primary', className = '' }) => {
  let bg = 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-500/30';
  if (color === 'success') bg = 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-500/30';
  if (color === 'danger') bg = 'bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-500/30';

  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-14 h-14 rounded-full flex items-center justify-center transition-transform hover:scale-105 active:scale-95 cursor-pointer ${bg} ${className}`}
    >
      {children}
    </button>
  );
};

/* -------------------------------------------------------------------------- */
/* MODAL, TOAST, LOADING, ALERT                                              */
/* -------------------------------------------------------------------------- */
export const IonModal: React.FC<{ 
  isOpen: boolean; 
  onDidDismiss: () => void; 
  title?: string;
  children: React.ReactNode; 
}> = ({ isOpen, onDidDismiss, title, children }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) onDidDismiss();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onDidDismiss]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/40 backdrop-blur-2xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-xl shadow-xl max-w-lg w-full max-h-[90vh] flex flex-col overflow-hidden border border-gray-200 animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-5 py-3.5 border-b border-gray-100 flex items-center justify-between bg-white">
          <h3 className="font-bold text-gray-900 text-base">{title || 'Detalles'}</h3>
          <button 
            onClick={onDidDismiss}
            className="text-gray-400 hover:text-gray-700 p-1 rounded-md hover:bg-gray-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-5 overflow-y-auto flex-1">{children}</div>
      </div>
    </div>
  );
};

export const IonToast: React.FC<{
  isOpen: boolean;
  message: string;
  duration?: number;
  color?: 'success' | 'danger' | 'warning' | 'primary';
  onDidDismiss: () => void;
}> = ({ isOpen, message, duration = 3000, color = 'success', onDidDismiss }) => {
  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        onDidDismiss();
      }, duration);
      return () => clearTimeout(timer);
    }
  }, [isOpen, duration, onDidDismiss]);

  if (!isOpen) return null;

  let bg = 'bg-slate-900 text-white';
  let icon = <Check className="w-5 h-5 text-emerald-400" />;
  if (color === 'success') {
    bg = 'bg-emerald-950 text-emerald-100 border border-emerald-800';
    icon = <Check className="w-5 h-5 text-emerald-400" />;
  } else if (color === 'danger') {
    bg = 'bg-rose-950 text-rose-100 border border-rose-800';
    icon = <AlertCircle className="w-5 h-5 text-rose-400" />;
  } else if (color === 'primary') {
    bg = 'bg-blue-950 text-blue-100 border border-blue-800';
    icon = <Info className="w-5 h-5 text-blue-400" />;
  }

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-in slide-in-from-bottom-5 duration-300">
      <div className={`px-4 py-3 rounded-xl shadow-xl flex items-center gap-3 text-sm font-medium max-w-sm ${bg}`}>
        {icon}
        <span className="flex-1">{message}</span>
        <button onClick={onDidDismiss} className="text-white/60 hover:text-white p-1">
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* STAR RATING COMPONENT                                                      */
/* -------------------------------------------------------------------------- */
export const StarRating: React.FC<{
  value: number;
  onChange?: (val: number) => void;
  readOnly?: boolean;
  size?: 'sm' | 'md' | 'lg';
}> = ({ value, onChange, readOnly = false, size = 'md' }) => {
  const stars = [1, 2, 3, 4, 5];
  const sizeClasses = size === 'sm' ? 'w-4 h-4' : size === 'lg' ? 'w-7 h-7' : 'w-5 h-5';

  return (
    <div className="flex items-center gap-1">
      {stars.map((star) => {
        const isFilled = star <= value;
        return (
          <button
            key={star}
            type="button"
            disabled={readOnly}
            onClick={() => onChange && onChange(star)}
            className={`${readOnly ? 'cursor-default' : 'cursor-pointer hover:scale-110 transition-transform'} p-0.5`}
          >
            <Star
              className={`${sizeClasses} ${
                isFilled ? 'fill-amber-400 text-amber-400' : 'text-slate-300 fill-slate-100'
              }`}
            />
          </button>
        );
      })}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* SLIDING ITEM EMULATION                                                     */
/* -------------------------------------------------------------------------- */
export const IonItemSliding: React.FC<{
  children: React.ReactNode;
  onDelete?: () => void;
  onStatusChange?: () => void;
}> = ({ children, onDelete, onStatusChange }) => {
  const [swiped, setSwiped] = useState(false);

  return (
    <div className="relative overflow-hidden rounded-xl bg-white border border-slate-200/80 mb-2">
      <div 
        className={`transition-transform duration-200 ${swiped ? '-translate-x-32' : 'translate-x-0'}`}
        onClick={() => setSwiped(!swiped)}
      >
        {children}
      </div>
      <div className="absolute top-0 bottom-0 right-0 flex items-center justify-end w-32 bg-slate-100 border-l border-slate-200">
        {onStatusChange && (
          <button
            onClick={() => {
              onStatusChange();
              setSwiped(false);
            }}
            className="h-full px-3 bg-blue-600 text-white flex items-center justify-center font-medium text-xs hover:bg-blue-700 transition-colors"
            title="Cambiar Estado"
          >
            Estado
          </button>
        )}
        {onDelete && (
          <button
            onClick={() => {
              onDelete();
              setSwiped(false);
            }}
            className="h-full px-3 bg-rose-600 text-white flex items-center justify-center font-medium text-xs hover:bg-rose-700 transition-colors"
            title="Eliminar"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
