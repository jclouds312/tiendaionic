import React, { useState } from 'react';
import { 
  BookOpen, 
  Utensils, 
  ChefHat, 
  MessageSquare, 
  Menu, 
  X, 
  Smartphone, 
  Tablet, 
  Monitor, 
  RotateCcw,
  Sparkles,
  Info,
  User,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';
import { LogoComponent } from './LogoComponent';

export type ActiveProject = 'books' | 'restaurants' | 'recipes' | 'suggestions';

interface MobileFrameProps {
  activeProject: ActiveProject;
  setActiveProject: (project: ActiveProject) => void;
  children: React.ReactNode;
  onResetAll?: () => void;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({
  activeProject,
  setActiveProject,
  children,
  onResetAll
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [deviceView, setDeviceView] = useState<'mobile' | 'tablet' | 'full'>('mobile');

  const navItems = [
    {
      id: 'books' as ActiveProject,
      title: 'Catálogo de Libros',
      subtitle: 'Proyecto 1 - Control de Lecturas',
      icon: <BookOpen className="w-5 h-5" />,
      color: 'bg-blue-600'
    },
    {
      id: 'restaurants' as ActiveProject,
      title: 'Restaurantes',
      subtitle: 'Proyecto 2 - Catálogo & Menú',
      icon: <Utensils className="w-5 h-5" />,
      color: 'bg-emerald-600'
    },
    {
      id: 'recipes' as ActiveProject,
      title: 'Catálogo de Recetas',
      subtitle: 'Proyecto 3 - Recetario Completo',
      icon: <ChefHat className="w-5 h-5" />,
      color: 'bg-amber-600'
    },
    {
      id: 'suggestions' as ActiveProject,
      title: 'Buzón de Sugerencias',
      subtitle: 'Proyecto 4 - Formulario & Rating',
      icon: <MessageSquare className="w-5 h-5" />,
      color: 'bg-rose-600'
    }
  ];

  const currentProject = navItems.find(item => item.id === activeProject);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans">
      {/* Top Global Control Bar - Premium Ionic & Material 3 Bar */}
      <header className="h-16 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 md:px-6 flex items-center justify-between z-40 shadow-xs sticky top-0">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsMenuOpen(true)}
            className="p-2 rounded-xl border border-slate-200/80 text-slate-700 hover:bg-slate-100 hover:text-blue-600 transition-all cursor-pointer active:scale-95 shadow-2xs"
            title="Abrir Menú de Arquitectura"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <LogoComponent size="md" showText={true} />
        </div>

        {/* View mode switcher & Reset */}
        <div className="flex items-center gap-2">
          <div className="bg-slate-100/90 p-1 rounded-xl flex items-center gap-1 border border-slate-200">
            <button
              onClick={() => setDeviceView('mobile')}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                deviceView === 'mobile' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Vista Móvil"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Móvil</span>
            </button>
            <button
              onClick={() => setDeviceView('tablet')}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                deviceView === 'tablet' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Vista Tablet"
            >
              <Tablet className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Tablet</span>
            </button>
            <button
              onClick={() => setDeviceView('full')}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                deviceView === 'full' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Pantalla Completa"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Full</span>
            </button>
          </div>

          {onResetAll && (
            <button
              onClick={onResetAll}
              className="p-2 rounded-xl border border-slate-200/80 text-slate-600 hover:text-blue-600 hover:bg-slate-100 transition-all cursor-pointer active:scale-95 shadow-2xs"
              title="Restablecer Datos Iniciales"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}
        </div>
      </header>

      {/* Side Menu Drawer (Premium Ionic Drawer with User Avatar & Info) */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div 
            className="fixed inset-0 bg-slate-950/40 backdrop-blur-2xs animate-in fade-in duration-200"
            onClick={() => setIsMenuOpen(false)}
          />
          <aside className="relative w-80 max-w-[85vw] bg-white border-r border-slate-200 flex flex-col z-50 shadow-2xl animate-in slide-in-from-left duration-250">
            {/* Header & User Avatar Profile */}
            <div className="p-5 border-b border-slate-100 bg-gradient-to-b from-slate-50 to-white flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <LogoComponent size="md" showText={true} />
                <button 
                  onClick={() => setIsMenuOpen(false)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* User Profile Info Card */}
              <div className="p-3 bg-white rounded-xl border border-slate-200/80 shadow-2xs flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-sm shadow-xs shrink-0">
                  <User className="w-5 h-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-900 text-xs truncate">Usuario Root / Admin</span>
                    <ShieldCheck className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  </div>
                  <p className="text-[10px] text-slate-500 font-mono truncate">Ionic Standalone & Base44</p>
                </div>
              </div>
            </div>

            {/* Navigation & Projects */}
            <div className="p-4 flex-1 overflow-y-auto space-y-6">
              <div>
                <p className="text-[10px] font-extrabold text-slate-400 uppercase mb-3 px-1 tracking-wider">
                  Módulos de la Aplicación
                </p>
                <div className="space-y-2">
                  {navItems.map((item) => {
                    const isActive = activeProject === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActiveProject(item.id);
                          setIsMenuOpen(false);
                        }}
                        className={`w-full p-3 rounded-xl flex items-center gap-3 transition-all text-left cursor-pointer border ${
                          isActive 
                            ? 'bg-blue-50/80 text-blue-900 border-blue-200 shadow-2xs font-semibold' 
                            : 'bg-white text-slate-700 border-slate-100 hover:bg-slate-50 hover:border-slate-200'
                        }`}
                      >
                        <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-white shrink-0 shadow-2xs ${item.color}`}>
                          {item.icon}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-bold truncate text-slate-900">{item.title}</div>
                          <div className="text-[10px] text-slate-500 truncate">{item.subtitle}</div>
                        </div>
                        <ChevronRight className={`w-4 h-4 transition-transform ${isActive ? 'text-blue-600 translate-x-0.5' : 'text-slate-300'}`} />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Core Stack */}
              <div className="pt-2 border-t border-slate-100">
                <p className="text-[10px] font-extrabold text-slate-400 uppercase mb-2.5 px-1 tracking-wider">
                  Arquitectura & Entorno
                </p>
                <div className="grid grid-cols-2 gap-2 px-1">
                  <span className="bg-slate-100 text-slate-700 text-[10px] py-1.5 px-2.5 rounded-lg font-mono border border-slate-200 text-center font-medium">Angular / React</span>
                  <span className="bg-slate-100 text-slate-700 text-[10px] py-1.5 px-2.5 rounded-lg font-mono border border-slate-200 text-center font-medium">Ionic 8</span>
                  <span className="bg-slate-100 text-slate-700 text-[10px] py-1.5 px-2.5 rounded-lg font-mono border border-slate-200 text-center font-medium">Capacitor</span>
                  <span className="bg-slate-100 text-slate-700 text-[10px] py-1.5 px-2.5 rounded-lg font-mono border border-slate-200 text-center font-medium">Base44 Ready</span>
                </div>
              </div>
            </div>

            {/* Footer Status */}
            <div className="p-4 border-t border-slate-100 bg-slate-50">
              <div className="bg-slate-900 rounded-xl p-3 text-white shadow-xs">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] text-slate-400 font-semibold uppercase">Estado de Producción</p>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                </div>
                <p className="text-xs font-mono text-emerald-400 font-bold mt-0.5">ESTADO: PRODUCCIÓN OK</p>
              </div>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Area with Clean Minimal Device Frame Wrapper */}
      <main className="flex-1 flex items-center justify-center p-0 md:p-6 overflow-y-auto">
        <div 
          className={`w-full bg-white text-slate-900 transition-all duration-300 flex flex-col overflow-hidden ${
            deviceView === 'mobile'
              ? 'max-w-[420px] h-[840px] max-h-[92vh] rounded-[28px] shadow-xl border border-slate-300 ring-1 ring-slate-200/80'
              : deviceView === 'tablet'
              ? 'max-w-[768px] h-[880px] max-h-[92vh] rounded-[22px] shadow-xl border border-slate-300 ring-1 ring-slate-200/80'
              : 'max-w-6xl min-h-[85vh] rounded-2xl shadow-md border border-slate-200'
          }`}
        >
          {/* Simulated Mobile Status Bar */}
          {deviceView !== 'full' && (
            <div className="bg-slate-950 text-slate-300 px-6 py-1.5 flex items-center justify-between text-[11px] font-mono border-b border-slate-800 select-none">
              <span>9:41</span>
              <div className="w-16 h-3 bg-slate-800 rounded-full mx-auto" />
              <div className="flex items-center gap-1.5 text-[10px]">
                <span>5G</span>
                <span className="text-emerald-400">100%</span>
              </div>
            </div>
          )}

          {/* Project View Container */}
          <div className="flex-1 flex flex-col overflow-y-auto bg-slate-50/60 relative">
            {children}
          </div>

          {/* Bottom Tabs Navigation for Mobile/Tablet */}
          <nav className="bg-white/95 backdrop-blur-md border-t border-slate-200/80 px-2 py-2 flex items-center justify-around z-30 shadow-xs">
            {navItems.map((item) => {
              const isActive = activeProject === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveProject(item.id)}
                  className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all cursor-pointer ${
                    isActive ? 'text-blue-600 font-bold bg-blue-50/80' : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <div className={`p-0.5 transition-transform ${isActive ? 'scale-110' : ''}`}>
                    {item.icon}
                  </div>
                  <span className="text-[10px] tracking-tight font-semibold">{item.title.replace('Catálogo de ', '')}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </main>
    </div>
  );
};

