import React from 'react';

interface SkeletonLoaderProps {
  count?: number;
  type?: 'card' | 'list' | 'detail';
}

export const SkeletonLoader: React.FC<SkeletonLoaderProps> = ({
  count = 3,
  type = 'card'
}) => {
  const items = Array.from({ length: count });

  if (type === 'list') {
    return (
      <div className="space-y-3 w-full animate-pulse">
        {items.map((_, i) => (
          <div key={i} className="p-4 bg-white rounded-xl border border-gray-100 flex items-center gap-4">
            <div className="w-12 h-12 bg-gray-200 rounded-lg shrink-0" />
            <div className="flex-1 space-y-2">
              <div className="h-4 bg-gray-200 rounded w-3/4" />
              <div className="h-3 bg-gray-150 rounded w-1/2" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (type === 'detail') {
    return (
      <div className="space-y-4 w-full animate-pulse p-4">
        <div className="h-48 bg-gray-200 rounded-2xl w-full" />
        <div className="h-6 bg-gray-200 rounded w-2/3" />
        <div className="h-4 bg-gray-150 rounded w-1/3" />
        <div className="space-y-2 pt-4">
          <div className="h-3 bg-gray-200 rounded w-full" />
          <div className="h-3 bg-gray-200 rounded w-5/6" />
          <div className="h-3 bg-gray-200 rounded w-4/6" />
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full animate-pulse">
      {items.map((_, i) => (
        <div key={i} className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-xs">
          <div className="h-36 bg-gray-200 w-full" />
          <div className="p-4 space-y-3">
            <div className="h-4 bg-gray-200 rounded w-3/4" />
            <div className="h-3 bg-gray-150 rounded w-1/2" />
            <div className="pt-2 flex justify-between items-center">
              <div className="h-3 bg-gray-200 rounded w-1/4" />
              <div className="h-3 bg-gray-200 rounded w-1/4" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
