import React from 'react';

interface LogoComponentProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export const LogoComponent: React.FC<LogoComponentProps> = ({
  className = '',
  size = 'md',
  showText = true
}) => {
  const sizeClasses = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-10 h-10'
  };

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      {/* Premium Minimalist SVG Logo Icon */}
      <div className={`${sizeClasses[size]} relative flex items-center justify-center rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-500 shadow-md shadow-blue-500/20 text-white p-1.5 transition-transform hover:scale-105`}>
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-full h-full"
        >
          <path d="M12 2L2 7l10 5 10-5-10-5z" />
          <path d="M2 17l10 5 10-5" />
          <path d="M2 12l10 5 10-5" />
        </svg>
        <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-white" />
      </div>

      {showText && (
        <div className="flex flex-col">
          <span className="font-extrabold text-sm tracking-tight text-gray-900 dark:text-white leading-none">
            Ionic<span className="text-blue-600 dark:text-blue-400">Hub</span>
          </span>
          <span className="text-[10px] font-semibold text-gray-400 tracking-wider uppercase mt-0.5">
            Base44 Ready
          </span>
        </div>
      )}
    </div>
  );
};
