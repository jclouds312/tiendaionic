export const environment = {
  production: false,
  appName: 'Ionic Suite Academic - Clean Minimalism',
  apiVersion: 'v1',
  enableDebugLogs: true
};
