export const environment = {
  production: true,
  appName: 'Ionic Suite Academic - Clean Minimalism',
  apiVersion: 'v1',
  enableDebugLogs: false
};
