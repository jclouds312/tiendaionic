import { Suggestion, SuggestionStatus, SuggestionFormData } from '../models/suggestion.model';

const STORAGE_KEY = 'academic_suggestions_db_v1';

const INITIAL_SUGGESTIONS: Suggestion[] = [
  {
    id: 'sug-1',
    title: 'Ampliación de Horarios en Biblioteca Central',
    category: 'Infraestructura',
    description: 'Solicito cordialmente que durante el periodo de exámenes finales se extienda el horario de apertura de la biblioteca hasta las 11:00 PM para favorecer el estudio en grupo.',
    rating: 5,
    status: 'Aprobada',
    createdAt: new Date(2025, 2, 10, 14, 30).toISOString(),
    authorName: 'Carlos Mendoza',
    email: 'carlos.mendoza@alumnos.edu.mx',
    responseNote: 'Sugerencia aprobada por la Dirección Académica. Se habilitará el horario extendido a partir del próximo mes.'
  },
  {
    id: 'sug-2',
    title: 'Mejora en la Conectividad Wi-Fi del Campus Norte',
    category: 'Tecnología',
    description: 'En los edificios B y C la red de internet presenta intermitencias constantes durante las clases vespertinas, lo que dificulta el acceso a las plataformas de aprendizaje.',
    rating: 4,
    status: 'En Revisión',
    createdAt: new Date(2025, 2, 18, 9, 15).toISOString(),
    authorName: 'Sofía Martínez',
    email: 'sofia.martinez@alumnos.edu.mx',
    responseNote: 'El departamento de TI se encuentra realizando pruebas de ancho de banda e instalación de nuevos repetidores.'
  },
  {
    id: 'sug-3',
    title: 'Implementación de Opciones Veganas en la Cafetería',
    category: 'Servicio al Cliente',
    description: 'Sería un excelente aporte incluir un menú diario balanceado con platillos 100% vegetarianos y veganos en la cafetería principal.',
    rating: 5,
    status: 'Pendiente',
    createdAt: new Date(2025, 3, 2, 16, 45).toISOString(),
    authorName: 'Ana Lucía Gómez',
    email: 'ana.gomez@alumnos.edu.mx'
  },
  {
    id: 'sug-4',
    title: 'Talleres de Repaso de Matemáticas Avanzadas',
    category: 'Académico',
    description: 'Sugerimos organizar tutorías los sábados por la mañana impartidas por alumnos de semestres superiores para reforzar las asignaturas de cálculo y álgebra.',
    rating: 4,
    status: 'Pendiente',
    createdAt: new Date(2025, 3, 12, 11, 20).toISOString(),
    authorName: 'Roberto Esquivel',
    email: 'roberto.esquivel@alumnos.edu.mx'
  }
];

class SuggestionService {
  private suggestions: Suggestion[] = [];

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        this.suggestions = JSON.parse(stored);
      } else {
        this.suggestions = [...INITIAL_SUGGESTIONS];
        this.saveToStorage();
      }
    } catch {
      this.suggestions = [...INITIAL_SUGGESTIONS];
    }
  }

  private saveToStorage() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.suggestions));
    } catch (e) {
      console.error('Error saving suggestions to storage', e);
    }
  }

  getAll(): Suggestion[] {
    return [...this.suggestions];
  }

  getById(id: string): Suggestion | undefined {
    return this.suggestions.find(s => s.id === id);
  }

  add(data: SuggestionFormData): Suggestion {
    const newSuggestion: Suggestion = {
      ...data,
      id: `sug-${Date.now()}`,
      status: 'Pendiente',
      createdAt: new Date().toISOString()
    };
    this.suggestions.unshift(newSuggestion);
    this.saveToStorage();
    return newSuggestion;
  }

  updateStatus(id: string, status: SuggestionStatus, responseNote?: string): Suggestion | undefined {
    const sug = this.suggestions.find(s => s.id === id);
    if (sug) {
      sug.status = status;
      if (responseNote !== undefined) {
        sug.responseNote = responseNote;
      }
      this.saveToStorage();
    }
    return sug;
  }

  delete(id: string): boolean {
    const initialLength = this.suggestions.length;
    this.suggestions = this.suggestions.filter(s => s.id !== id);
    if (this.suggestions.length !== initialLength) {
      this.saveToStorage();
      return true;
    }
    return false;
  }

  getByStatus(statusFilter: string): Suggestion[] {
    if (statusFilter === 'Todas' || statusFilter === 'all') return this.getAll();
    return this.suggestions.filter(s => s.status === statusFilter);
  }

  resetToDefaults(): void {
    this.suggestions = [...INITIAL_SUGGESTIONS];
    this.saveToStorage();
  }
}

export const suggestionService = new SuggestionService();
