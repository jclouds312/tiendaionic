import { Restaurant, RestaurantCategoryFilter } from '../models/restaurant.model';

const STORAGE_KEY = 'academic_restaurants_db_v1';

const INITIAL_RESTAURANTS: Restaurant[] = [
  {
    id: 'rest-1',
    name: 'El Mareño Mariscos & Grill',
    category: 'Mariscos',
    rating: 4.8,
    favorite: true,
    isFavorite: true,
    address: 'Av. Costera Miguel Alemán #120, Zona Dorada',
    phone: '+52 (744) 484-9020',
    imageUrl: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80',
    priceRange: '$$$',
    schedule: 'Lun - Dom: 12:00 PM - 11:00 PM',
    description: 'Especialidades marinas preparadas con la pesca más fresca del día. Disfruta de tostadas de atún aleta azul, ceviche peruano y filete a las brasas.',
    menu: [
      { id: 'm1', name: 'Ceviche Mixto Tradicional', price: 240, description: 'Camarón, pulpo y pescado en jugo de limón fresco y chile habanero', category: 'Entradas', isPopular: true },
      { id: 'm2', name: 'Tostada de Atún Sellado', price: 180, description: 'Atún fresco sobre tostada con poro frito, aguacate y aderezo chipotle', category: 'Entradas', isPopular: true },
      { id: 'm3', name: 'Pescado Zarandeado (Kg)', price: 490, description: 'Filete horneado a las brasas con adobo de chiles secos y especias', category: 'Platillos Fuertes' },
      { id: 'm4', name: 'Margarita de Maracuyá', price: 120, description: 'Tequila reposado con pulpa natural de maracuyá y sal de gusano', category: 'Bebidas' }
    ]
  },
  {
    id: 'rest-2',
    name: 'Trattoria Bella Italia',
    category: 'Italiana',
    rating: 4.9,
    favorite: true,
    isFavorite: true,
    address: 'Calle Roma #45, Col. Juárez',
    phone: '+52 (55) 5207-1122',
    imageUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80',
    priceRange: '$$$',
    schedule: 'Mar - Dom: 1:00 PM - 11:30 PM',
    description: 'Auténtica pasta hecha a mano artesanalmente todos los días. Pizzas en horno de leña napolitano y selecta cava de vinos italianos.',
    menu: [
      { id: 'm5', name: 'Fettuccine Alfredo con Trufa', price: 290, description: 'Pasta fresca bañada en crema parmesana artesanal y aceite de trufa blanca', category: 'Pastas', isPopular: true },
      { id: 'm6', name: 'Pizza Margherita DOC', price: 260, description: 'Salsa de tomate San Marzano, mozzarella fior di latte y albahaca fresca', category: 'Pizzas', isPopular: true },
      { id: 'm7', name: 'Tiramisú Clásico', price: 140, description: 'Bizcochos soletilla empapados en café espresso, licor y queso mascarpone', category: 'Postres' }
    ]
  },
  {
    id: 'rest-3',
    name: 'La Mezcalería Cantina & Tacos',
    category: 'Mexicana',
    rating: 4.7,
    favorite: false,
    isFavorite: false,
    address: 'Plaza Mayor #88, Centro Histórico',
    phone: '+52 (55) 5512-3344',
    imageUrl: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=800&q=80',
    priceRange: '$$',
    schedule: 'Lun - Sáb: 1:00 PM - 1:00 AM',
    description: 'Celebración de la gastronomía oaxaqueña y mexicana con recetas tradicionales de mole, barbacoa de hoyo y degustación de mezcales artesanales.',
    menu: [
      { id: 'm8', name: 'Mole Negro Oaxaqueño', price: 280, description: 'Pechuga de pollo bañada en mole artesanal de 30 ingredientes', category: 'Platillos Fuertes', isPopular: true },
      { id: 'm9', name: 'Tacos de Rib Eye con Tuétano', price: 220, description: 'Tres tacos en tortilla de maíz nixtamalizado con salsa martajada', category: 'Tacos' }
    ]
  },
  {
    id: 'rest-4',
    name: 'Café & BISTRO Aroma',
    category: 'Cafés',
    rating: 4.6,
    favorite: false,
    isFavorite: false,
    address: 'Av. Universidad #500, Del Valle',
    phone: '+52 (55) 5604-9876',
    imageUrl: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=800&q=80',
    priceRange: '$',
    schedule: 'Lun - Dom: 7:00 AM - 9:00 PM',
    description: 'Café de especialidad con granos de origen único de Chiapas y Veracruz. Panadería horneada diariamente y desayunos gourmet.',
    menu: [
      { id: 'm10', name: 'Flat White de Especialidad', price: 75, description: 'Espresso doble con leche texturizada cremosa', category: 'Cafés', isPopular: true },
      { id: 'm11', name: 'Toast de Aguacate y Huevo Pochado', price: 145, description: 'Pan sourdough integral, aguacate machacado, tomate cherry y pepita', category: 'Desayunos' }
    ]
  }
];

class RestaurantService {
  private restaurants: Restaurant[] = [];

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        this.restaurants = JSON.parse(stored);
      } else {
        this.restaurants = [...INITIAL_RESTAURANTS];
        this.saveToStorage();
      }
    } catch {
      this.restaurants = [...INITIAL_RESTAURANTS];
    }
  }

  private saveToStorage() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.restaurants));
    } catch (e) {
      console.error('Error saving restaurants to storage', e);
    }
  }

  getAll(): Restaurant[] {
    return [...this.restaurants];
  }

  getById(id: string): Restaurant | undefined {
    return this.restaurants.find(r => r.id === id);
  }

  getFavorites(): Restaurant[] {
    return this.restaurants.filter(r => r.favorite || r.isFavorite);
  }

  toggleFavorite(id: string): Restaurant | undefined {
    const restaurant = this.restaurants.find(r => r.id === id);
    if (restaurant) {
      const newFav = !(restaurant.favorite ?? restaurant.isFavorite);
      restaurant.favorite = newFav;
      restaurant.isFavorite = newFav;
      this.saveToStorage();
    }
    return restaurant;
  }

  add(restaurantData: Omit<Restaurant, 'id'>): Restaurant {
    const isFav = restaurantData.favorite ?? restaurantData.isFavorite ?? false;
    const newRest: Restaurant = {
      ...restaurantData,
      favorite: isFav,
      isFavorite: isFav,
      id: `rest-${Date.now()}`
    };
    this.restaurants.unshift(newRest);
    this.saveToStorage();
    return newRest;
  }

  getByCategory(category: RestaurantCategoryFilter): Restaurant[] {
    if (category === 'Todos') return this.getAll();
    if (category === 'Favoritos') return this.getFavorites();
    return this.restaurants.filter(r => r.category === category);
  }

  resetToDefaults(): void {
    this.restaurants = [...INITIAL_RESTAURANTS];
    this.saveToStorage();
  }
}

export const restaurantService = new RestaurantService();
