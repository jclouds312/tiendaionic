import { Book } from '../models/book.model';

const STORAGE_KEY = 'academic_books_db_v1';

const INITIAL_BOOKS: Book[] = [
  {
    id: 'book-1',
    title: 'Cien Años de Soledad',
    author: 'Gabriel García Márquez',
    read: true,
    genre: 'Realismo Mágico',
    rating: 5,
    coverUrl: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=600&q=80',
    description: 'La obra cumbre de Gabriel García Márquez narra la historia de la familia Buendía a lo largo de siete generaciones en el pueblo ficticio de Macondo.',
    publishYear: 1967,
    totalPages: 417,
    addedAt: new Date(2025, 1, 10).toISOString()
  },
  {
    id: 'book-2',
    title: 'El Principito',
    author: 'Antoine de Saint-Exupéry',
    read: true,
    genre: 'Literatura Infantil / Filosofía',
    rating: 5,
    coverUrl: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80',
    description: 'Un joven príncipe que visita varios planetas en el espacio, incluyendo la Tierra. Trata temas como la soledad, la amistad, el amor y la pérdida.',
    publishYear: 1943,
    totalPages: 96,
    addedAt: new Date(2025, 2, 1).toISOString()
  },
  {
    id: 'book-3',
    title: 'Don Quijote de la Mancha',
    author: 'Miguel de Cervantes',
    read: false,
    genre: 'Novela de Caballerías',
    rating: 4,
    coverUrl: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=600&q=80',
    description: 'Alonso Quijano pierde el juicio leyendo libros de caballerías y decide armarse caballero andante junto a su fiel escudero Sancho Panza.',
    publishYear: 1605,
    totalPages: 1088,
    addedAt: new Date(2025, 2, 15).toISOString()
  },
  {
    id: 'book-4',
    title: '1984',
    author: 'George Orwell',
    read: false,
    genre: 'Distopía',
    rating: 5,
    coverUrl: 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&w=600&q=80',
    description: 'Una inquietante interpretación distópica del futuro en la que la Gran Hermana o el Gran Hermano todo lo ve y todo lo controla.',
    publishYear: 1949,
    totalPages: 328,
    addedAt: new Date(2025, 3, 2).toISOString()
  },
  {
    id: 'book-5',
    title: 'Rayuela',
    author: 'Julio Cortázar',
    read: true,
    genre: 'Novela Experimental',
    rating: 4,
    coverUrl: 'https://images.unsplash.com/photo-1476275466078-4007374efbbe?auto=format&fit=crop&w=600&q=80',
    description: 'La historia de Horacio Oliveira y su relación con la Maga en París y Buenos Aires, estructurada para ser leída de múltiples formas.',
    publishYear: 1963,
    totalPages: 600,
    addedAt: new Date(2025, 3, 10).toISOString()
  }
];

class BookService {
  private books: Book[] = [];

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        this.books = JSON.parse(stored);
      } else {
        this.books = [...INITIAL_BOOKS];
        this.saveToStorage();
      }
    } catch {
      this.books = [...INITIAL_BOOKS];
    }
  }

  private saveToStorage() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.books));
    } catch (e) {
      console.error('Error saving books to storage', e);
    }
  }

  getAll(): Book[] {
    return [...this.books];
  }

  getById(id: string): Book | undefined {
    return this.books.find(b => b.id === id);
  }

  add(bookData: Omit<Book, 'id' | 'addedAt'>): Book {
    const newBook: Book = {
      ...bookData,
      id: `book-${Date.now()}`,
      addedAt: new Date().toISOString(),
      coverUrl: bookData.coverUrl || 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&w=600&q=80'
    };
    this.books.unshift(newBook);
    this.saveToStorage();
    return newBook;
  }

  toggleRead(id: string): Book | undefined {
    const book = this.books.find(b => b.id === id);
    if (book) {
      book.read = !book.read;
      this.saveToStorage();
    }
    return book;
  }

  delete(id: string): boolean {
    const initialLength = this.books.length;
    this.books = this.books.filter(b => b.id !== id);
    if (this.books.length !== initialLength) {
      this.saveToStorage();
      return true;
    }
    return false;
  }

  resetToDefaults(): void {
    this.books = [...INITIAL_BOOKS];
    this.saveToStorage();
  }
}

export const bookService = new BookService();
