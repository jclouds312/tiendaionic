export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

export interface NavigationItem {
  id: string;
  title: string;
  subtitle: string;
  iconName: string;
  route: string;
}

export interface PaginationMeta {
  currentPage: number;
  totalPages: number;
  totalItems: number;
  itemsPerPage: number;
}

export interface FilterOptions {
  searchQuery?: string;
  category?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}
