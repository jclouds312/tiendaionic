import React, { useState } from 'react';
import { SuggestionCategory, SuggestionFormData } from '../../models/suggestion.model';
import { suggestionService } from '../../services/suggestion.service';
import { 
  IonModal, 
  IonButton, 
  StarRating 
} from '../../components/shared/IonicUI';
import { AlertCircle, CheckCircle2, Mail, User, Tag, FileText } from 'lucide-react';

interface NewSuggestionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuggestionCreated: () => void;
}

export const NewSuggestionModal: React.FC<NewSuggestionModalProps> = ({
  isOpen,
  onClose,
  onSuggestionCreated
}) => {
  // Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<SuggestionCategory>('Infraestructura');
  const [description, setDescription] = useState('');
  const [rating, setRating] = useState(5);
  const [authorName, setAuthorName] = useState('');
  const [email, setEmail] = useState('');

  // Touched state trackers for reactive validation
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const handleBlur = (field: string) => {
    setTouched(prev => ({ ...prev, [field]: true }));
  };

  // Validation rules
  const isTitleValid = title.trim().length >= 5;
  const isDescriptionValid = description.trim().length >= 15;
  const isAuthorValid = authorName.trim().length >= 3;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const isEmailValid = emailRegex.test(email);

  const isFormValid = isTitleValid && isDescriptionValid && isAuthorValid && isEmailValid;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFormValid) {
      setTouched({ title: true, description: true, authorName: true, email: true });
      return;
    }

    const newFormData: SuggestionFormData = {
      title: title.trim(),
      category,
      description: description.trim(),
      rating,
      authorName: authorName.trim(),
      email: email.trim()
    };

    suggestionService.add(newFormData);
    onSuggestionCreated();
    resetForm();
    onClose();
  };

  const resetForm = () => {
    setTitle('');
    setCategory('Infraestructura');
    setDescription('');
    setRating(5);
    setAuthorName('');
    setEmail('');
    setTouched({});
  };

  return (
    <IonModal isOpen={isOpen} onDidDismiss={onClose} title="Enviar Nueva Sugerencia">
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Title input with validation */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1 flex items-center justify-between">
            <span>Título de la Sugerencia *</span>
            {touched.title && (
              <span className={`text-[11px] font-semibold ${isTitleValid ? 'text-emerald-600' : 'text-rose-600'}`}>
                {isTitleValid ? '✓ Correcto' : 'Mínimo 5 caracteres'}
              </span>
            )}
          </label>
          <div className="relative">
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              onBlur={() => handleBlur('title')}
              placeholder="Ej: Ampliación de horarios de laboratorio"
              className={`w-full px-3 py-2 bg-slate-50 border rounded-xl text-sm focus:outline-hidden transition-all ${
                touched.title 
                  ? isTitleValid 
                    ? 'border-emerald-500 bg-emerald-50/20' 
                    : 'border-rose-500 bg-rose-50/20' 
                  : 'border-slate-200 focus:ring-2 focus:ring-blue-500/30'
              }`}
            />
          </div>
        </div>

        {/* Category & Rating */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Categoría
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as SuggestionCategory)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
            >
              <option value="Infraestructura">Infraestructura</option>
              <option value="Servicio al Cliente">Servicio al Cliente</option>
              <option value="Académico">Académico</option>
              <option value="Tecnología">Tecnología</option>
              <option value="Otros">Otros</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Calificación Servicio
            </label>
            <StarRating value={rating} onChange={setRating} size="md" />
          </div>
        </div>

        {/* Description Input */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1 flex items-center justify-between">
            <span>Descripción Detallada *</span>
            {touched.description && (
              <span className={`text-[11px] font-semibold ${isDescriptionValid ? 'text-emerald-600' : 'text-rose-600'}`}>
                {isDescriptionValid ? '✓ Correcto' : 'Mínimo 15 caracteres'}
              </span>
            )}
          </label>
          <textarea
            rows={3}
            required
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            onBlur={() => handleBlur('description')}
            placeholder="Explica detalladamente la propuesta o aspecto a mejorar..."
            className={`w-full px-3 py-2 bg-slate-50 border rounded-xl text-sm focus:outline-hidden transition-all ${
              touched.description 
                ? isDescriptionValid 
                  ? 'border-emerald-500 bg-emerald-50/20' 
                  : 'border-rose-500 bg-rose-50/20' 
                : 'border-slate-200 focus:ring-2 focus:ring-blue-500/30'
            }`}
          />
        </div>

        {/* Author Name */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1 flex items-center justify-between">
            <span>Nombre del Emisor *</span>
            {touched.authorName && (
              <span className={`text-[11px] font-semibold ${isAuthorValid ? 'text-emerald-600' : 'text-rose-600'}`}>
                {isAuthorValid ? '✓ Válido' : 'Requerido'}
              </span>
            )}
          </label>
          <input
            type="text"
            required
            value={authorName}
            onChange={(e) => setAuthorName(e.target.value)}
            onBlur={() => handleBlur('authorName')}
            placeholder="Ej: Carlos Mendoza"
            className={`w-full px-3 py-2 bg-slate-50 border rounded-xl text-sm focus:outline-hidden transition-all ${
              touched.authorName 
                ? isAuthorValid 
                  ? 'border-emerald-500 bg-emerald-50/20' 
                  : 'border-rose-500 bg-rose-50/20' 
                : 'border-slate-200 focus:ring-2 focus:ring-blue-500/30'
            }`}
          />
        </div>

        {/* Email with Regex Validation */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1 flex items-center justify-between">
            <span>Correo Electrónico *</span>
            {touched.email && (
              <span className={`text-[11px] font-semibold ${isEmailValid ? 'text-emerald-600' : 'text-rose-600'}`}>
                {isEmailValid ? '✓ Email válido' : 'Formato inválido (usuario@dominio.com)'}
              </span>
            )}
          </label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            onBlur={() => handleBlur('email')}
            placeholder="carlos.mendoza@alumnos.edu.mx"
            className={`w-full px-3 py-2 bg-slate-50 border rounded-xl text-sm focus:outline-hidden transition-all ${
              touched.email 
                ? isEmailValid 
                  ? 'border-emerald-500 bg-emerald-50/20' 
                  : 'border-rose-500 bg-rose-50/20' 
                : 'border-slate-200 focus:ring-2 focus:ring-blue-500/30'
            }`}
          />
        </div>

        <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
          <IonButton fill="clear" color="medium" onClick={onClose}>
            Cancelar
          </IonButton>
          <IonButton type="submit" color="primary" disabled={!isFormValid}>
            Enviar Sugerencia
          </IonButton>
        </div>
      </form>
    </IonModal>
  );
};
