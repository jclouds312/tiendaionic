import React, { useState, useEffect } from 'react';
import { Suggestion, SuggestionStatus } from '../../models/suggestion.model';
import { suggestionService } from '../../services/suggestion.service';
import { NewSuggestionModal } from './NewSuggestionModal';
import { EmptyState } from '../../components/shared/EmptyState';
import { 
  IonHeader, 
  IonToolbar, 
  IonTitle, 
  IonButtons, 
  IonButton, 
  IonBadge, 
  IonSegment, 
  IonSegmentButton, 
  IonFab, 
  IonFabButton, 
  IonItemSliding, 
  IonToast,
  StarRating
} from '../../components/shared/IonicUI';
import { 
  MessageSquare, 
  Plus, 
  Search, 
  Trash2, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  User, 
  Mail, 
  Sparkles,
  Info
} from 'lucide-react';

export const SuggestionsHomePage: React.FC = () => {
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [activeSegment, setActiveSegment] = useState<string>('Todas');
  const [searchQuery, setSearchQuery] = useState('');
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setSuggestions(suggestionService.getAll());
  };

  const handleDeleteSuggestion = (id: string, title: string) => {
    if (suggestionService.delete(id)) {
      setToastMessage(`Sugerencia "${title}" eliminada.`);
      refreshData();
    }
  };

  const handleCycleStatus = (id: string) => {
    const sug = suggestionService.getById(id);
    if (!sug) return;

    let nextStatus: SuggestionStatus = 'En Revisión';
    if (sug.status === 'Pendiente') nextStatus = 'En Revisión';
    else if (sug.status === 'En Revisión') nextStatus = 'Aprobada';
    else if (sug.status === 'Aprobada') nextStatus = 'Pendiente';

    suggestionService.updateStatus(id, nextStatus);
    setToastMessage(`Estado de "${sug.title}" actualizado a ${nextStatus}`);
    refreshData();
  };

  const segmentsList = ['Todas', 'Pendiente', 'En Revisión', 'Aprobada'];

  const filteredSuggestions = suggestions.filter(s => {
    const matchesSegment = activeSegment === 'Todas' ? true : s.status === activeSegment;
    const matchesSearch = 
      s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.authorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSegment && matchesSearch;
  });

  const getStatusBadgeColor = (status: SuggestionStatus) => {
    if (status === 'Aprobada') return 'success';
    if (status === 'En Revisión') return 'primary';
    if (status === 'Rechazada') return 'danger';
    return 'warning';
  };

  return (
    <div className="flex flex-col min-h-full pb-20">
      <IonHeader>
        <IonToolbar color="primary">
          <IonTitle>📮 Buzón de Sugerencias</IonTitle>
          <IonButtons slot="end">
            <IonButton fill="clear" color="light" onClick={() => setIsNewModalOpen(true)}>
              <Plus className="w-5 h-5" />
            </IonButton>
          </IonButtons>
        </IonToolbar>

        {/* Stats bar */}
        <div className="bg-rose-700 text-white px-4 py-2 flex items-center justify-between text-xs font-medium">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-200" />
            <span>Total registradas: {suggestions.length}</span>
          </div>
          <span className="bg-white/20 px-2.5 py-0.5 rounded-full font-bold">
            Atendidas: {suggestions.filter(s => s.status === 'Aprobada').length}
          </span>
        </div>

        {/* Search & Segments */}
        <div className="p-3 bg-white border-b border-slate-100">
          <div className="relative mb-2.5">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar por título, emisor o categoría..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-100 rounded-xl text-sm border-0 focus:outline-hidden focus:ring-2 focus:ring-blue-500/30 text-slate-800"
            />
          </div>

          <IonSegment value={activeSegment} onIonChange={(v) => setActiveSegment(v)}>
            {segmentsList.map(seg => (
              <IonSegmentButton key={seg} value={seg}>
                {seg}
              </IonSegmentButton>
            ))}
          </IonSegment>
        </div>
      </IonHeader>

      <div className="p-4 space-y-3 flex-1">
        {/* Tip banner for sliding items */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 flex items-center gap-2.5 text-xs text-blue-800">
          <Info className="w-4 h-4 text-blue-600 shrink-0" />
          <span>Tip: Haz clic en una tarjeta para deslizar opciones de Estado o Eliminar.</span>
        </div>

        {filteredSuggestions.length === 0 ? (
          <EmptyState
            type={searchQuery ? 'search' : 'empty'}
            title={searchQuery ? 'Sin sugerencias encontradas' : 'Buzón Vacío'}
            description="Sé el primero en enviar una propuesta o cambia los filtros de búsqueda."
            actionLabel="Crear Sugerencia"
            onAction={() => setIsNewModalOpen(true)}
            className="my-4"
          />
        ) : (
          filteredSuggestions.map((sug) => (
            <IonItemSliding
              key={sug.id}
              onDelete={() => handleDeleteSuggestion(sug.id, sug.title)}
              onStatusChange={() => handleCycleStatus(sug.id)}
            >
              <div className="p-4 bg-white">
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md">
                    {sug.category}
                  </span>
                  <IonBadge color={getStatusBadgeColor(sug.status)}>
                    {sug.status}
                  </IonBadge>
                </div>

                <h3 className="font-bold text-slate-800 text-base leading-tight">{sug.title}</h3>
                <p className="text-xs text-slate-600 mt-1.5 leading-relaxed bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                  {sug.description}
                </p>

                {sug.responseNote && (
                  <div className="mt-2 text-xs bg-emerald-50 border border-emerald-200 text-emerald-800 p-2.5 rounded-lg">
                    <span className="font-bold block mb-0.5">Respuesta Institucional:</span>
                    {sug.responseNote}
                  </div>
                )}

                <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                  <div className="flex items-center gap-2">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    <span className="font-semibold text-slate-700">{sug.authorName}</span>
                  </div>

                  <StarRating value={sug.rating} readOnly size="sm" />
                </div>
              </div>
            </IonItemSliding>
          ))
        )}
      </div>

      {/* Floating Action Button */}
      <IonFab vertical="bottom" horizontal="end">
        <IonFabButton onClick={() => setIsNewModalOpen(true)} color="primary">
          <Plus className="w-6 h-6" />
        </IonFabButton>
      </IonFab>

      {/* New Suggestion Form Modal */}
      <NewSuggestionModal
        isOpen={isNewModalOpen}
        onClose={() => setIsNewModalOpen(false)}
        onSuggestionCreated={() => {
          setToastMessage('¡Sugerencia registrada con éxito!');
          refreshData();
        }}
      />

      <IonToast
        isOpen={!!toastMessage}
        message={toastMessage || ''}
        onDidDismiss={() => setToastMessage(null)}
      />
    </div>
  );
};
