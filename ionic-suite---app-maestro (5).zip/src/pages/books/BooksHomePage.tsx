import React, { useState, useEffect } from 'react';
import { Book, BookFilter } from '../../models/book.model';
import { bookService } from '../../services/book.service';
import { EmptyState } from '../../components/shared/EmptyState';
import { 
  IonHeader, 
  IonToolbar, 
  IonTitle, 
  IonButtons, 
  IonButton, 
  IonCard, 
  IonBadge, 
  IonSegment, 
  IonSegmentButton, 
  IonFab, 
  IonFabButton, 
  IonModal, 
  IonToast,
  StarRating
} from '../../components/shared/IonicUI';
import { 
  BookOpen, 
  Plus, 
  CheckCircle2, 
  Circle, 
  Search, 
  Trash2, 
  Eye, 
  Bookmark,
  Sparkles
} from 'lucide-react';

interface BooksHomePageProps {
  onSelectBook: (bookId: string) => void;
}

export const BooksHomePage: React.FC<BooksHomePageProps> = ({ onSelectBook }) => {
  const [books, setBooks] = useState<Book[]>([]);
  const [filter, setFilter] = useState<BookFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form State
  const [newTitle, setNewTitle] = useState('');
  const [newAuthor, setNewAuthor] = useState('');
  const [newGenre, setNewGenre] = useState('Ficción');
  const [newRating, setNewRating] = useState(5);
  const [newPages, setNewPages] = useState(250);
  const [newDescription, setNewDescription] = useState('');

  useEffect(() => {
    refreshBooks();
  }, []);

  const refreshBooks = () => {
    setBooks(bookService.getAll());
  };

  const handleToggleRead = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const updated = bookService.toggleRead(id);
    if (updated) {
      setToastMessage(
        updated.read ? `"${updated.title}" marcado como LEÍDO` : `"${updated.title}" marcado como PENDIENTE`
      );
      refreshBooks();
    }
  };

  const handleDeleteBook = (e: React.MouseEvent, id: string, title: string) => {
    e.stopPropagation();
    if (bookService.delete(id)) {
      setToastMessage(`Libro "${title}" eliminado.`);
      refreshBooks();
    }
  };

  const handleAddBook = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newAuthor.trim()) return;

    bookService.add({
      title: newTitle,
      author: newAuthor,
      genre: newGenre,
      rating: newRating,
      totalPages: Number(newPages),
      read: false,
      description: newDescription || 'Sin descripción ingresada.'
    });

    setToastMessage('¡Nuevo libro añadido con éxito al catálogo!');
    setIsAddModalOpen(false);
    resetForm();
    refreshBooks();
  };

  const resetForm = () => {
    setNewTitle('');
    setNewAuthor('');
    setNewGenre('Ficción');
    setNewRating(5);
    setNewPages(250);
    setNewDescription('');
  };

  const filteredBooks = books.filter(b => {
    const matchesFilter = 
      filter === 'all' ? true : filter === 'read' ? b.read : !b.read;
    const matchesSearch = 
      b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (b.genre && b.genre.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesFilter && matchesSearch;
  });

  const readCount = books.filter(b => b.read).length;
  const unreadCount = books.filter(b => !b.read).length;

  return (
    <div className="flex flex-col min-h-full pb-20">
      <IonHeader>
        <IonToolbar color="primary">
          <IonTitle>📚 Catálogo de Libros</IonTitle>
          <IonButtons slot="end">
            <IonButton fill="clear" color="light" onClick={() => setIsAddModalOpen(true)}>
              <Plus className="w-5 h-5" />
            </IonButton>
          </IonButtons>
        </IonToolbar>

        {/* Stats banner */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white px-4 py-3 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span className="font-medium">Progreso de Lectura:</span>
          </div>
          <div className="flex gap-3 font-semibold">
            <span className="bg-white/20 px-2 py-0.5 rounded-full">Leídos: {readCount}</span>
            <span className="bg-white/20 px-2 py-0.5 rounded-full">Pendientes: {unreadCount}</span>
          </div>
        </div>

        {/* Search bar */}
        <div className="p-3 bg-white border-b border-slate-100">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar por título, autor o género..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-100 rounded-xl text-sm border-0 focus:outline-hidden focus:ring-2 focus:ring-blue-500/30 text-slate-800"
            />
          </div>

          <IonSegment value={filter} onIonChange={(v) => setFilter(v as BookFilter)} className="mt-2.5">
            <IonSegmentButton value="all">Todos ({books.length})</IonSegmentButton>
            <IonSegmentButton value="read">Leídos ({readCount})</IonSegmentButton>
            <IonSegmentButton value="unread">Pendientes ({unreadCount})</IonSegmentButton>
          </IonSegment>
        </div>
      </IonHeader>

      <div className="p-4 space-y-3 flex-1">
        {filteredBooks.length === 0 ? (
          <EmptyState
            type={searchQuery ? 'search' : 'empty'}
            title={searchQuery ? 'Sin coincidencias' : 'Catálogo Vacío'}
            description={searchQuery ? 'No encontramos libros que coincidan con la búsqueda.' : 'Empieza agregando tu primer libro a la biblioteca.'}
            actionLabel="Agregar Libro"
            onAction={() => setIsAddModalOpen(true)}
            className="my-6"
          />
        ) : (
          filteredBooks.map((book) => (
            <IonCard key={book.id} onClick={() => onSelectBook(book.id)}>
              <div className="p-4 flex gap-3.5 items-start">
                {book.coverUrl ? (
                  <img 
                    src={book.coverUrl} 
                    alt={book.title} 
                    className="w-16 h-24 object-cover rounded-lg shadow-xs shrink-0 bg-slate-100"
                  />
                ) : (
                  <div className="w-16 h-24 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center shrink-0">
                    <Bookmark className="w-8 h-8" />
                  </div>
                )}

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-bold text-slate-800 text-base leading-tight truncate">{book.title}</h3>
                    <IonBadge color={book.read ? 'success' : 'warning'}>
                      {book.read ? 'Leído' : 'Pendiente'}
                    </IonBadge>
                  </div>

                  <p className="text-xs font-medium text-slate-500 mt-1">Por: {book.author}</p>
                  
                  {book.genre && (
                    <span className="inline-block mt-1 text-[11px] font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md">
                      {book.genre}
                    </span>
                  )}

                  {book.rating && (
                    <div className="mt-2 flex items-center gap-2">
                      <StarRating value={book.rating} readOnly size="sm" />
                      <span className="text-[11px] text-slate-400">({book.rating}/5)</span>
                    </div>
                  )}

                  <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2 text-xs">
                    <button
                      onClick={(e) => handleToggleRead(e, book.id)}
                      className={`inline-flex items-center gap-1 font-semibold px-2.5 py-1 rounded-lg transition-colors ${
                        book.read 
                          ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100' 
                          : 'bg-amber-50 text-amber-700 hover:bg-amber-100'
                      }`}
                    >
                      {book.read ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Mark Pending
                        </>
                      ) : (
                        <>
                          <Circle className="w-3.5 h-3.5 text-amber-600" /> Marcar Leído
                        </>
                      )}
                    </button>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectBook(book.id);
                        }}
                        className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Ver detalle"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={(e) => handleDeleteBook(e, book.id, book.title)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Eliminar libro"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </IonCard>
          ))
        )}
      </div>

      {/* Floating Action Button */}
      <IonFab vertical="bottom" horizontal="end">
        <IonFabButton onClick={() => setIsAddModalOpen(true)} color="primary">
          <Plus className="w-6 h-6" />
        </IonFabButton>
      </IonFab>

      {/* Add Book IonModal */}
      <IonModal
        isOpen={isAddModalOpen}
        onDidDismiss={() => setIsAddModalOpen(false)}
        title="Añadir Nuevo Libro"
      >
        <form onSubmit={handleAddBook} className="space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Título del Libro *
            </label>
            <input
              type="text"
              required
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="Ej: Cien Años de Soledad"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Autor *
            </label>
            <input
              type="text"
              required
              value={newAuthor}
              onChange={(e) => setNewAuthor(e.target.value)}
              placeholder="Ej: Gabriel García Márquez"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
                Género
              </label>
              <select
                value={newGenre}
                onChange={(e) => setNewGenre(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
              >
                <option value="Ficción">Ficción</option>
                <option value="Realismo Mágico">Realismo Mágico</option>
                <option value="Ciencia Ficción">Ciencia Ficción</option>
                <option value="Filosofía">Filosofía</option>
                <option value="Historia">Historia</option>
                <option value="Desarrollo Personal">Desarrollo Personal</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
                Páginas
              </label>
              <input
                type="number"
                min="10"
                value={newPages}
                onChange={(e) => setNewPages(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Valoración Personal (1-5)
            </label>
            <StarRating value={newRating} onChange={setNewRating} size="lg" />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Sinopsis / Descripción
            </label>
            <textarea
              rows={3}
              value={newDescription}
              onChange={(e) => setNewDescription(e.target.value)}
              placeholder="Resumen del libro o notas de lectura..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
            <IonButton fill="clear" color="medium" onClick={() => setIsAddModalOpen(false)}>
              Cancelar
            </IonButton>
            <IonButton type="submit" color="primary">
              Guardar Libro
            </IonButton>
          </div>
        </form>
      </IonModal>

      {/* Toast Notification */}
      <IonToast
        isOpen={!!toastMessage}
        message={toastMessage || ''}
        onDidDismiss={() => setToastMessage(null)}
      />
    </div>
  );
};
