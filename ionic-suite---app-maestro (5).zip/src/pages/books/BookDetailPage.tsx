import React, { useState, useEffect } from 'react';
import { Book } from '../../models/book.model';
import { bookService } from '../../services/book.service';
import { 
  IonHeader, 
  IonToolbar, 
  IonTitle, 
  IonButtons, 
  IonBackButton, 
  IonButton, 
  IonBadge, 
  IonToast,
  StarRating
} from '../../components/shared/IonicUI';
import { 
  BookOpen, 
  CheckCircle2, 
  Circle, 
  Calendar, 
  FileText, 
  Trash2, 
  Bookmark,
  Share2
} from 'lucide-react';

interface BookDetailPageProps {
  bookId: string;
  onBack: () => void;
}

export const BookDetailPage: React.FC<BookDetailPageProps> = ({ bookId, onBack }) => {
  const [book, setBook] = useState<Book | undefined>(undefined);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    loadBook();
  }, [bookId]);

  const loadBook = () => {
    setBook(bookService.getById(bookId));
  };

  if (!book) {
    return (
      <div className="p-6 text-center">
        <p className="text-slate-500 mb-4">Libro no encontrado.</p>
        <IonButton onClick={onBack}>Regresar al Catálogo</IonButton>
      </div>
    );
  }

  const handleToggleRead = () => {
    const updated = bookService.toggleRead(book.id);
    if (updated) {
      setBook({ ...updated });
      setToastMessage(updated.read ? 'Libro marcado como Leído' : 'Libro marcado como Pendiente');
    }
  };

  const handleDelete = () => {
    if (window.confirm(`¿Seguro que deseas eliminar "${book.title}"?`)) {
      bookService.delete(book.id);
      onBack();
    }
  };

  return (
    <div className="flex flex-col min-h-full pb-10 bg-slate-50">
      <IonHeader>
        <IonToolbar color="primary">
          <IonButtons slot="start">
            <IonBackButton onClick={onBack} text="Volver" />
          </IonButtons>
          <IonTitle>Detalle del Libro</IonTitle>
          <IonButtons slot="end">
            <button 
              onClick={handleDelete}
              className="p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-white/10"
              title="Eliminar"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </IonButtons>
        </IonToolbar>
      </IonHeader>

      <div className="p-4 space-y-4 max-w-lg mx-auto w-full">
        {/* Cover Hero Banner */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs flex flex-col items-center text-center">
          {book.coverUrl ? (
            <img 
              src={book.coverUrl} 
              alt={book.title} 
              className="w-36 h-52 object-cover rounded-xl shadow-md mb-4 bg-slate-100"
            />
          ) : (
            <div className="w-36 h-52 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center mb-4 shadow-inner">
              <Bookmark className="w-16 h-16" />
            </div>
          )}

          <IonBadge color={book.read ? 'success' : 'warning'} className="mb-2">
            {book.read ? '✓ Estado: Leído' : '⏳ Estado: Pendiente de Lectura'}
          </IonBadge>

          <h1 className="font-extrabold text-slate-800 text-xl tracking-tight leading-tight">{book.title}</h1>
          <p className="text-sm font-semibold text-blue-600 mt-1">Autor: {book.author}</p>

          {book.genre && (
            <span className="mt-2 text-xs font-semibold px-3 py-1 bg-slate-100 text-slate-600 rounded-full">
              {book.genre}
            </span>
          )}

          {book.rating && (
            <div className="mt-3 flex items-center gap-2">
              <StarRating value={book.rating} readOnly size="md" />
              <span className="text-xs font-bold text-slate-700">({book.rating} / 5 estrellas)</span>
            </div>
          )}

          <div className="mt-5 w-full flex items-center gap-2">
            <IonButton 
              onClick={handleToggleRead} 
              color={book.read ? 'medium' : 'success'}
              className="flex-1"
            >
              {book.read ? (
                <>
                  <Circle className="w-4 h-4 mr-2" /> Marcar Pendiente
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4 mr-2" /> Marcar Como Leído
                </>
              )}
            </IonButton>
          </div>
        </div>

        {/* Metadata Details Grid */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs space-y-3">
          <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider text-slate-400 border-b border-slate-100 pb-2">
            Información Técnica
          </h3>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="flex items-center gap-2.5 p-2.5 bg-slate-50 rounded-xl">
              <Calendar className="w-4 h-4 text-blue-500 shrink-0" />
              <div>
                <span className="text-slate-400 block">Año Publicación</span>
                <span className="font-bold text-slate-700">{book.publishYear || 'N/A'}</span>
              </div>
            </div>

            <div className="flex items-center gap-2.5 p-2.5 bg-slate-50 rounded-xl">
              <FileText className="w-4 h-4 text-emerald-500 shrink-0" />
              <div>
                <span className="text-slate-400 block">Total Páginas</span>
                <span className="font-bold text-slate-700">{book.totalPages || 'N/A'} págs</span>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">
              Sinopsis
            </span>
            <p className="text-sm text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
              {book.description || 'No se ha agregado una descripción formal para este título.'}
            </p>
          </div>
        </div>
      </div>

      <IonToast
        isOpen={!!toastMessage}
        message={toastMessage || ''}
        onDidDismiss={() => setToastMessage(null)}
      />
    </div>
  );
};
