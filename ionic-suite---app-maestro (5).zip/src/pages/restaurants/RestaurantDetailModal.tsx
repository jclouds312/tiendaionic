import React, { useState } from 'react';
import { Restaurant } from '../../models/restaurant.model';
import { restaurantService } from '../../services/restaurant.service';
import { 
  IonModal, 
  IonButton, 
  IonBadge, 
  IonToast,
  StarRating
} from '../../components/shared/IonicUI';
import { 
  Heart, 
  MapPin, 
  Phone, 
  Clock, 
  Utensils, 
  DollarSign, 
  Share2,
  Check
} from 'lucide-react';

interface RestaurantDetailModalProps {
  restaurant: Restaurant | null;
  isOpen: boolean;
  onClose: () => void;
  onFavoriteToggled?: () => void;
}

export const RestaurantDetailModal: React.FC<RestaurantDetailModalProps> = ({
  restaurant,
  isOpen,
  onClose,
  onFavoriteToggled
}) => {
  const [activeTab, setActiveTab] = useState<'info' | 'menu'>('info');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  if (!restaurant) return null;

  const handleToggleFav = () => {
    const updated = restaurantService.toggleFavorite(restaurant.id);
    if (updated) {
      const isFav = updated.favorite || updated.isFavorite;
      setToastMessage(
        isFav 
          ? `Agregado a favoritos` 
          : `Removido de favoritos`
      );
      if (onFavoriteToggled) onFavoriteToggled();
    }
  };

  return (
    <IonModal isOpen={isOpen} onDidDismiss={onClose} title={restaurant.name}>
      <div className="space-y-4">
        {/* Cover image banner */}
        <div className="relative rounded-2xl overflow-hidden h-44 bg-slate-100 shadow-inner">
          <img 
            src={restaurant.imageUrl} 
            alt={restaurant.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex items-end p-4">
            <div className="flex-1 text-white">
              <span className="text-xs font-bold uppercase tracking-wider bg-blue-600 px-2.5 py-0.5 rounded-md">
                {restaurant.category}
              </span>
              <h2 className="font-extrabold text-xl text-white mt-1 leading-tight">{restaurant.name}</h2>
            </div>

            <button
              onClick={handleToggleFav}
              className={`p-2.5 rounded-full backdrop-blur-md transition-all cursor-pointer ${
                (restaurant.favorite || restaurant.isFavorite)
                  ? 'bg-rose-600 text-white shadow-md' 
                  : 'bg-white/30 text-white hover:bg-white/50'
              }`}
            >
              <Heart className={`w-5 h-5 ${(restaurant.favorite || restaurant.isFavorite) ? 'fill-white' : ''}`} />
            </button>
          </div>
        </div>

        {/* Tab switch */}
        <div className="flex bg-slate-100 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('info')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'info' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600'
            }`}
          >
            Información
          </button>
          <button
            onClick={() => setActiveTab('menu')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'menu' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600'
            }`}
          >
            Menú Digital ({restaurant.menu.length})
          </button>
        </div>

        {activeTab === 'info' ? (
          <div className="space-y-3 text-sm">
            <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-100">
              <div className="flex items-center gap-2">
                <StarRating value={Math.round(restaurant.rating)} readOnly size="sm" />
                <span className="font-bold text-slate-800 text-sm">{restaurant.rating} / 5.0</span>
              </div>
              <span className="font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg text-xs">
                Precio: {restaurant.priceRange}
              </span>
            </div>

            <p className="text-slate-600 text-xs leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
              {restaurant.description}
            </p>

            <div className="space-y-2 text-xs">
              <div className="flex items-start gap-2 text-slate-600 p-2 rounded-lg hover:bg-slate-50">
                <MapPin className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-700 block">Ubicación</span>
                  <span>{restaurant.address}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 text-slate-600 p-2 rounded-lg hover:bg-slate-50">
                <Phone className="w-4 h-4 text-emerald-500 shrink-0" />
                <div>
                  <span className="font-bold text-slate-700 block">Teléfono / Reservaciones</span>
                  <span>{restaurant.phone}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 text-slate-600 p-2 rounded-lg hover:bg-slate-50">
                <Clock className="w-4 h-4 text-amber-500 shrink-0" />
                <div>
                  <span className="font-bold text-slate-700 block">Horario de Atención</span>
                  <span>{restaurant.schedule}</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
            {restaurant.menu.length === 0 ? (
              <p className="text-center text-xs text-slate-400 py-6">No hay platillos registrados en el menú.</p>
            ) : (
              restaurant.menu.map((item) => (
                <div key={item.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-800 text-sm">{item.name}</h4>
                      {item.isPopular && (
                        <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded-md">
                          ★ Popular
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">{item.description}</p>
                    <span className="inline-block mt-1 text-[10px] text-slate-400 font-semibold uppercase">
                      {item.category}
                    </span>
                  </div>

                  <span className="font-extrabold text-blue-600 text-sm bg-blue-50 px-2.5 py-1 rounded-lg shrink-0">
                    ${item.price}
                  </span>
                </div>
              ))
            )}
          </div>
        )}

        <div className="pt-2 border-t border-slate-100 flex justify-end">
          <IonButton fill="clear" color="medium" onClick={onClose}>
            Cerrar
          </IonButton>
        </div>
      </div>

      <IonToast
        isOpen={!!toastMessage}
        message={toastMessage || ''}
        onDidDismiss={() => setToastMessage(null)}
      />
    </IonModal>
  );
};
