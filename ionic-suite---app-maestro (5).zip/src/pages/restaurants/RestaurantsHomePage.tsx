import React, { useState, useEffect } from 'react';
import { Restaurant, RestaurantCategoryFilter } from '../../models/restaurant.model';
import { restaurantService } from '../../services/restaurant.service';
import { RestaurantDetailModal } from './RestaurantDetailModal';
import { EmptyState } from '../../components/shared/EmptyState';
import { 
  IonHeader, 
  IonToolbar, 
  IonTitle, 
  IonButtons, 
  IonButton, 
  IonCard, 
  IonBadge, 
  IonSegment, 
  IonSegmentButton, 
  IonFab, 
  IonFabButton, 
  IonModal, 
  IonToast,
  StarRating
} from '../../components/shared/IonicUI';
import { 
  Utensils, 
  Heart, 
  MapPin, 
  Plus, 
  Search, 
  Sparkles,
  Phone,
  Clock
} from 'lucide-react';

export const RestaurantsHomePage: React.FC = () => {
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [activeCategory, setActiveCategory] = useState<RestaurantCategoryFilter>('Todos');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [category, setCategory] = useState<Restaurant['category']>('Mariscos');
  const [rating, setRating] = useState(4.5);
  const [priceRange, setPriceRange] = useState<Restaurant['priceRange']>('$$');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [schedule, setSchedule] = useState('Lun - Dom: 12:00 PM - 10:00 PM');
  const [imageUrl, setImageUrl] = useState('https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80');
  const [description, setDescription] = useState('');

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setRestaurants(restaurantService.getAll());
  };

  const handleToggleFavorite = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const updated = restaurantService.toggleFavorite(id);
    if (updated) {
      const isFav = updated.favorite || updated.isFavorite;
      setToastMessage(
        isFav 
          ? `⭐ "${updated.name}" agregado a tus Favoritos` 
          : `"${updated.name}" eliminado de Favoritos`
      );
      refreshData();
      if (selectedRestaurant?.id === id) {
        setSelectedRestaurant({ ...updated });
      }
    }
  };

  const handleOpenDetail = (rest: Restaurant) => {
    setSelectedRestaurant(rest);
    setIsDetailModalOpen(true);
  };

  const handleAddRestaurant = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !address.trim()) return;

    restaurantService.add({
      name,
      category,
      rating: Number(rating),
      favorite: false,
      isFavorite: false,
      address,
      phone: phone || '+52 (55) 0000-0000',
      imageUrl,
      priceRange,
      schedule,
      description: description || 'Restaurante con propuesta gastronómica excepcional.',
      menu: [
        { id: `m-${Date.now()}-1`, name: 'Especialidad de la Casa', price: 220, description: 'Platillo destacado del chef preparado al momento.', category: 'Especialidades', isPopular: true },
        { id: `m-${Date.now()}-2`, name: 'Bebida Artesanal', price: 85, description: 'Infusión o coctel distintivo del lugar.', category: 'Bebidas' }
      ]
    });

    setToastMessage('¡Restaurante registrado con éxito!');
    setIsAddModalOpen(false);
    resetForm();
    refreshData();
  };

  const resetForm = () => {
    setName('');
    setCategory('Mariscos');
    setRating(4.5);
    setPriceRange('$$');
    setAddress('');
    setPhone('');
    setDescription('');
  };

  const categoriesList: RestaurantCategoryFilter[] = [
    'Todos',
    'Favoritos',
    'Mariscos',
    'Italiana',
    'Mexicana',
    'Cafés'
  ];

  const filteredRestaurants = restaurants.filter(r => {
    let matchesCat = true;
    if (activeCategory === 'Favoritos') matchesCat = r.favorite || r.isFavorite || false;
    else if (activeCategory !== 'Todos') matchesCat = r.category === activeCategory;

    const matchesSearch = 
      r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.address.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCat && matchesSearch;
  });

  const favoritesCount = restaurants.filter(r => r.favorite || r.isFavorite).length;

  return (
    <div className="flex flex-col min-h-full pb-20">
      <IonHeader>
        <IonToolbar color="primary">
          <IonTitle>🍽️ Catálogo de Restaurantes</IonTitle>
          <IonButtons slot="end">
            <IonButton fill="clear" color="light" onClick={() => setIsAddModalOpen(true)}>
              <Plus className="w-5 h-5" />
            </IonButton>
          </IonButtons>
        </IonToolbar>

        {/* Header bar stats */}
        <div className="bg-emerald-700 text-white px-4 py-2 flex items-center justify-between text-xs font-medium">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Lugares registrados: {restaurants.length}</span>
          </div>
          <button 
            onClick={() => setActiveCategory('Favoritos')}
            className="flex items-center gap-1 bg-white/20 hover:bg-white/30 px-2.5 py-0.5 rounded-full font-bold transition-colors cursor-pointer"
          >
            <Heart className="w-3.5 h-3.5 fill-rose-300 text-rose-300" />
            <span>Mis Favoritos ({favoritesCount})</span>
          </button>
        </div>

        {/* Search & Categories Segment */}
        <div className="p-3 bg-white border-b border-slate-100">
          <div className="relative mb-2.5">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar restaurantes por nombre o zona..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-100 rounded-xl text-sm border-0 focus:outline-hidden focus:ring-2 focus:ring-blue-500/30 text-slate-800"
            />
          </div>

          <IonSegment value={activeCategory} onIonChange={(v) => setActiveCategory(v as RestaurantCategoryFilter)}>
            {categoriesList.map(cat => (
              <IonSegmentButton key={cat} value={cat}>
                {cat === 'Favoritos' ? '❤️ Favoritos' : cat}
              </IonSegmentButton>
            ))}
          </IonSegment>
        </div>
      </IonHeader>

      {/* Main Responsive Cards Grid */}
      <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-4 flex-1">
        {filteredRestaurants.length === 0 ? (
          <div className="col-span-full">
            <EmptyState
              type={searchQuery ? 'search' : 'empty'}
              title={searchQuery ? 'Sin resultados' : 'No hay restaurantes'}
              description="No encontramos establecimientos que coincidan con los filtros seleccionados."
              actionLabel="Registrar Restaurante"
              onAction={() => setIsAddModalOpen(true)}
              className="my-4"
            />
          </div>
        ) : (
          filteredRestaurants.map((rest) => (
            <IonCard key={rest.id} onClick={() => handleOpenDetail(rest)}>
              <div className="relative h-36 bg-slate-100">
                <img 
                  src={rest.imageUrl} 
                  alt={rest.name} 
                  className="w-full h-full object-cover"
                />
                <button
                  onClick={(e) => handleToggleFavorite(e, rest.id)}
                  className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-all cursor-pointer ${
                    (rest.favorite || rest.isFavorite)
                      ? 'bg-rose-600 text-white shadow-md' 
                      : 'bg-white/80 text-slate-600 hover:bg-white'
                  }`}
                  title={(rest.favorite || rest.isFavorite) ? 'Remover de favoritos' : 'Agregar a favoritos'}
                >
                  <Heart className={`w-4 h-4 ${(rest.favorite || rest.isFavorite) ? 'fill-white' : ''}`} />
                </button>

                <div className="absolute bottom-2 left-3 flex gap-1.5">
                  <span className="text-[10px] font-bold bg-slate-900/80 text-white px-2 py-0.5 rounded-md backdrop-blur-xs">
                    {rest.category}
                  </span>
                  <span className="text-[10px] font-bold bg-emerald-600 text-white px-2 py-0.5 rounded-md">
                    {rest.priceRange}
                  </span>
                </div>
              </div>

              <div className="p-4">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="font-bold text-slate-800 text-base truncate">{rest.name}</h3>
                  <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-md shrink-0">
                    <span className="text-amber-500 text-xs">★</span>
                    <span className="text-xs font-extrabold text-amber-700">{rest.rating}</span>
                  </div>
                </div>

                <div className="mt-2 flex items-center gap-1 text-xs text-slate-500 truncate">
                  <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                  <span className="truncate">{rest.address}</span>
                </div>

                <p className="mt-2 text-xs text-slate-600 line-clamp-2">
                  {rest.description}
                </p>

                <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-blue-600 font-bold hover:underline">Ver Menú ({rest.menu.length}) →</span>
                  <span className="text-[11px] text-slate-400 font-medium">{rest.schedule.split(':')[0]}</span>
                </div>
              </div>
            </IonCard>
          ))
        )}
      </div>

      {/* Floating Action Button */}
      <IonFab vertical="bottom" horizontal="end">
        <IonFabButton onClick={() => setIsAddModalOpen(true)} color="primary">
          <Plus className="w-6 h-6" />
        </IonFabButton>
      </IonFab>

      {/* Detail Modal */}
      <RestaurantDetailModal
        restaurant={selectedRestaurant}
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        onFavoriteToggled={refreshData}
      />

      {/* New Restaurant Modal */}
      <IonModal
        isOpen={isAddModalOpen}
        onDidDismiss={() => setIsAddModalOpen(false)}
        title="Registrar Restaurante"
      >
        <form onSubmit={handleAddRestaurant} className="space-y-3.5">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Nombre del Establecimiento *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ej: El Mareño Mariscos"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
                Categoría *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Restaurant['category'])}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
              >
                <option value="Mariscos">Mariscos</option>
                <option value="Italiana">Italiana</option>
                <option value="Mexicana">Mexicana</option>
                <option value="Cafés">Cafés</option>
                <option value="Internacional">Internacional</option>
                <option value="Cortes">Cortes</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
                Rango de Precio
              </label>
              <select
                value={priceRange}
                onChange={(e) => setPriceRange(e.target.value as Restaurant['priceRange'])}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
              >
                <option value="$">$ (Económico)</option>
                <option value="$$">$$ (Moderado)</option>
                <option value="$$$">$$$ (Gourmet)</option>
                <option value="$$$$">$$$$ (Lujo)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Dirección *
            </label>
            <input
              type="text"
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Ej: Av. Principal #120, Col. Centro"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Teléfono de Contacto
            </label>
            <input
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+52 (55) 5555-5555"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Descripción Breve
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Especialidades del restaurante..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
            <IonButton fill="clear" color="medium" onClick={() => setIsAddModalOpen(false)}>
              Cancelar
            </IonButton>
            <IonButton type="submit" color="primary">
              Guardar Restaurante
            </IonButton>
          </div>
        </form>
      </IonModal>

      <IonToast
        isOpen={!!toastMessage}
        message={toastMessage || ''}
        onDidDismiss={() => setToastMessage(null)}
      />
    </div>
  );
};
