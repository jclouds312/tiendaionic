import React, { useState, useEffect } from 'react';
import { Recipe, RecipeCategoryFilter } from '../../models/recipe.model';
import { recipeService } from '../../services/recipe.service';
import { EmptyState } from '../../components/shared/EmptyState';
import { 
  IonHeader, 
  IonToolbar, 
  IonTitle, 
  IonButtons, 
  IonButton, 
  IonCard, 
  IonBadge, 
  IonSegment, 
  IonSegmentButton, 
  IonFab, 
  IonFabButton, 
  IonModal, 
  IonToast
} from '../../components/shared/IonicUI';
import { 
  ChefHat, 
  Clock, 
  Flame, 
  Heart, 
  Plus, 
  Search, 
  Sparkles, 
  Trash2, 
  Eye,
  Minus
} from 'lucide-react';

interface RecipesHomePageProps {
  onSelectRecipe: (id: string) => void;
}

export const RecipesHomePage: React.FC<RecipesHomePageProps> = ({ onSelectRecipe }) => {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [activeCategory, setActiveCategory] = useState<RecipeCategoryFilter>('Todas');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<Recipe['category']>('Desayunos');
  const [prepTime, setPrepTime] = useState(20);
  const [difficulty, setDifficulty] = useState<Recipe['difficulty']>('Fácil');
  const [calories, setCalories] = useState(350);
  const [servings, setServings] = useState(4);
  const [imageUrl, setImageUrl] = useState('https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80');

  // Dynamic lists for ingredients & instructions
  const [ingredients, setIngredients] = useState<string[]>(['']);
  const [instructions, setInstructions] = useState<string[]>(['']);

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setRecipes(recipeService.getAll());
  };

  const handleToggleFavorite = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const updated = recipeService.toggleFavorite(id);
    if (updated) {
      const isFav = updated.favorite || updated.isFavorite;
      const rTitle = updated.name || updated.title;
      setToastMessage(
        isFav 
          ? `⭐ "${rTitle}" guardada en Favoritas` 
          : `"${rTitle}" removida de Favoritas`
      );
      refreshData();
    }
  };

  const handleAddRecipe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const validIngredients = ingredients.filter(i => i.trim().length > 0);
    const validInstructions = instructions.filter(i => i.trim().length > 0);

    recipeService.add({
      name: title,
      title,
      category,
      minutes: Number(prepTime),
      prepTime: Number(prepTime),
      favorite: false,
      isFavorite: false,
      ingredients: validIngredients.length > 0 ? validIngredients : ['Ingrediente principal'],
      instructions: validInstructions.length > 0 ? validInstructions : ['Paso de preparación por defecto.'],
      imageUrl,
      difficulty,
      calories: Number(calories),
      servings: Number(servings)
    });

    setToastMessage('¡Nueva receta añadida al recetario!');
    setIsAddModalOpen(false);
    resetForm();
    refreshData();
  };

  const resetForm = () => {
    setTitle('');
    setCategory('Desayunos');
    setPrepTime(20);
    setDifficulty('Fácil');
    setCalories(350);
    setServings(4);
    setIngredients(['']);
    setInstructions(['']);
  };

  const addIngredientField = () => setIngredients([...ingredients, '']);
  const updateIngredient = (index: number, val: string) => {
    const list = [...ingredients];
    list[index] = val;
    setIngredients(list);
  };
  const removeIngredientField = (index: number) => {
    if (ingredients.length > 1) {
      setIngredients(ingredients.filter((_, i) => i !== index));
    }
  };

  const addInstructionField = () => setInstructions([...instructions, '']);
  const updateInstruction = (index: number, val: string) => {
    const list = [...instructions];
    list[index] = val;
    setInstructions(list);
  };
  const removeInstructionField = (index: number) => {
    if (instructions.length > 1) {
      setInstructions(instructions.filter((_, i) => i !== index));
    }
  };

  const categoriesList: RecipeCategoryFilter[] = [
    'Todas',
    'Favoritas',
    'Desayunos',
    'Almuerzos',
    'Cenas',
    'Postres'
  ];

  const filteredRecipes = recipes.filter(r => {
    let matchesCat = true;
    if (activeCategory === 'Favoritas') matchesCat = r.favorite || r.isFavorite || false;
    else if (activeCategory !== 'Todas') matchesCat = r.category === activeCategory;

    const recipeTitle = r.name || r.title || '';
    const matchesSearch = 
      recipeTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.category.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCat && matchesSearch;
  });

  const favoritesCount = recipes.filter(r => r.favorite || r.isFavorite).length;

  return (
    <div className="flex flex-col min-h-full pb-20">
      <IonHeader>
        <IonToolbar color="primary">
          <IonTitle>👨‍🍳 Catálogo de Recetas</IonTitle>
          <IonButtons slot="end">
            <IonButton fill="clear" color="light" onClick={() => setIsAddModalOpen(true)}>
              <Plus className="w-5 h-5" />
            </IonButton>
          </IonButtons>
        </IonToolbar>

        {/* Top banner */}
        <div className="bg-amber-600 text-white px-4 py-2 flex items-center justify-between text-xs font-medium">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-200" />
            <span>Recetas disponibles: {recipes.length}</span>
          </div>
          <button 
            onClick={() => setActiveCategory('Favoritas')}
            className="flex items-center gap-1 bg-white/20 hover:bg-white/30 px-2.5 py-0.5 rounded-full font-bold transition-colors cursor-pointer"
          >
            <Heart className="w-3.5 h-3.5 fill-rose-300 text-rose-300" />
            <span>Favoritas ({favoritesCount})</span>
          </button>
        </div>

        {/* Search & Segments */}
        <div className="p-3 bg-white border-b border-slate-100">
          <div className="relative mb-2.5">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar receta o ingrediente..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-100 rounded-xl text-sm border-0 focus:outline-hidden focus:ring-2 focus:ring-blue-500/30 text-slate-800"
            />
          </div>

          <IonSegment value={activeCategory} onIonChange={(v) => setActiveCategory(v as RecipeCategoryFilter)}>
            {categoriesList.map(cat => (
              <IonSegmentButton key={cat} value={cat}>
                {cat === 'Favoritas' ? '❤️ Favoritas' : cat}
              </IonSegmentButton>
            ))}
          </IonSegment>
        </div>
      </IonHeader>

      {/* Grid of recipes */}
      <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-4 flex-1">
        {filteredRecipes.length === 0 ? (
          <div className="col-span-full">
            <EmptyState
              type={activeCategory === 'Favoritas' ? 'favorites' : searchQuery ? 'search' : 'empty'}
              title={activeCategory === 'Favoritas' ? 'Sin recetas favoritas' : searchQuery ? 'Sin resultados' : 'No hay recetas'}
              description="Prueba cambiar la categoría o agrega una nueva receta al recetario."
              actionLabel="Nueva Receta"
              onAction={() => setIsAddModalOpen(true)}
              className="my-4"
            />
          </div>
        ) : (
          filteredRecipes.map((recipe) => {
            const isFav = recipe.favorite || recipe.isFavorite;
            const titleVal = recipe.name || recipe.title;
            const prepMins = recipe.minutes ?? recipe.prepTime ?? 15;

            return (
              <IonCard key={recipe.id} onClick={() => onSelectRecipe(recipe.id)}>
                <div className="relative h-36 bg-slate-100">
                  <img 
                    src={recipe.imageUrl} 
                    alt={titleVal} 
                    className="w-full h-full object-cover"
                  />
                  <button
                    onClick={(e) => handleToggleFavorite(e, recipe.id)}
                    className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-all cursor-pointer ${
                      isFav 
                        ? 'bg-rose-600 text-white shadow-md' 
                        : 'bg-white/80 text-slate-600 hover:bg-white'
                    }`}
                    title={isFav ? 'Remover de favoritas' : 'Guardar en favoritas'}
                  >
                    <Heart className={`w-4 h-4 ${isFav ? 'fill-white' : ''}`} />
                  </button>

                  <div className="absolute bottom-2 left-3 flex gap-1.5">
                    <span className="text-[10px] font-bold bg-amber-500 text-slate-900 px-2 py-0.5 rounded-md">
                      {recipe.category}
                    </span>
                    <span className="text-[10px] font-bold bg-slate-900/80 text-white px-2 py-0.5 rounded-md backdrop-blur-xs">
                      {recipe.difficulty}
                    </span>
                  </div>
                </div>

                <div className="p-4">
                  <h3 className="font-bold text-slate-800 text-base truncate">{titleVal}</h3>

                  <div className="mt-2.5 flex items-center justify-between text-xs text-slate-500">
                    <div className="flex items-center gap-1 font-semibold text-slate-700">
                      <Clock className="w-3.5 h-3.5 text-blue-500" />
                      <span>{prepMins} min</span>
                    </div>

                    <div className="flex items-center gap-1 font-semibold text-slate-700">
                      <Flame className="w-3.5 h-3.5 text-rose-500" />
                      <span>{recipe.calories} kcal</span>
                    </div>

                    <span className="text-slate-400 font-medium">{recipe.ingredients.length} ingred.</span>
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-blue-600 font-bold hover:underline">Ver Preparación →</span>
                    <Eye className="w-4 h-4 text-slate-400" />
                  </div>
                </div>
              </IonCard>
            );
          })
        )}
      </div>

      {/* Floating Action Button */}
      <IonFab vertical="bottom" horizontal="end">
        <IonFabButton onClick={() => setIsAddModalOpen(true)} color="primary">
          <Plus className="w-6 h-6" />
        </IonFabButton>
      </IonFab>

      {/* Modal Nueva Receta */}
      <IonModal
        isOpen={isAddModalOpen}
        onDidDismiss={() => setIsAddModalOpen(false)}
        title="Crear Nueva Receta"
      >
        <form onSubmit={handleAddRecipe} className="space-y-3.5">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Nombre de la Receta *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ej: Ensalada César Gourmet"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
                Categoría
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Recipe['category'])}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
              >
                <option value="Desayunos">Desayunos</option>
                <option value="Almuerzos">Almuerzos</option>
                <option value="Cenas">Cenas</option>
                <option value="Postres">Postres</option>
                <option value="Bebidas">Bebidas</option>
                <option value="Ensaladas">Ensaladas</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
                Dificultad
              </label>
              <select
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value as Recipe['difficulty'])}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
              >
                <option value="Fácil">Fácil</option>
                <option value="Media">Media</option>
                <option value="Avanzada">Avanzada</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">
                Tiempo (Min)
              </label>
              <input
                type="number"
                min="5"
                value={prepTime}
                onChange={(e) => setPrepTime(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">
                Calorías
              </label>
              <input
                type="number"
                min="50"
                value={calories}
                onChange={(e) => setCalories(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold uppercase text-slate-600 mb-1">
                Porciones
              </label>
              <input
                type="number"
                min="1"
                value={servings}
                onChange={(e) => setServings(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
              />
            </div>
          </div>

          {/* Dynamic Ingredients list */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600">
                Ingredientes
              </label>
              <button
                type="button"
                onClick={addIngredientField}
                className="text-xs font-bold text-blue-600 hover:underline flex items-center gap-0.5"
              >
                <Plus className="w-3.5 h-3.5" /> Agregar
              </button>
            </div>
            <div className="space-y-1.5 max-h-32 overflow-y-auto">
              {ingredients.map((ing, idx) => (
                <div key={idx} className="flex items-center gap-1.5">
                  <input
                    type="text"
                    value={ing}
                    onChange={(e) => updateIngredient(idx, e.target.value)}
                    placeholder={`Ingrediente ${idx + 1}`}
                    className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  />
                  {ingredients.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeIngredientField(idx)}
                      className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Dynamic Instructions list */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600">
                Instrucciones Paso a Paso
              </label>
              <button
                type="button"
                onClick={addInstructionField}
                className="text-xs font-bold text-blue-600 hover:underline flex items-center gap-0.5"
              >
                <Plus className="w-3.5 h-3.5" /> Agregar Paso
              </button>
            </div>
            <div className="space-y-1.5 max-h-32 overflow-y-auto">
              {instructions.map((step, idx) => (
                <div key={idx} className="flex items-center gap-1.5">
                  <span className="text-xs font-bold text-slate-400 w-5">{idx + 1}.</span>
                  <input
                    type="text"
                    value={step}
                    onChange={(e) => updateInstruction(idx, e.target.value)}
                    placeholder={`Descripción del paso ${idx + 1}`}
                    className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  />
                  {instructions.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeInstructionField(idx)}
                      className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
            <IonButton fill="clear" color="medium" onClick={() => setIsAddModalOpen(false)}>
              Cancelar
            </IonButton>
            <IonButton type="submit" color="primary">
              Guardar Receta
            </IonButton>
          </div>
        </form>
      </IonModal>

      <IonToast
        isOpen={!!toastMessage}
        message={toastMessage || ''}
        onDidDismiss={() => setToastMessage(null)}
      />
    </div>
  );
};
