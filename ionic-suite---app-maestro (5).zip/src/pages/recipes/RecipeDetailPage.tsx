import React, { useState, useEffect } from 'react';
import { Recipe } from '../../models/recipe.model';
import { recipeService } from '../../services/recipe.service';
import { 
  IonHeader, 
  IonToolbar, 
  IonTitle, 
  IonButtons, 
  IonBackButton, 
  IonButton, 
  IonBadge, 
  IonToast
} from '../../components/shared/IonicUI';
import { 
  Clock, 
  Flame, 
  Users, 
  ChefHat, 
  Heart, 
  CheckSquare, 
  Square, 
  Trash2,
  Sparkles
} from 'lucide-react';

interface RecipeDetailPageProps {
  recipeId: string;
  onBack: () => void;
}

export const RecipeDetailPage: React.FC<RecipeDetailPageProps> = ({ recipeId, onBack }) => {
  const [recipe, setRecipe] = useState<Recipe | undefined>(undefined);
  const [checkedIngredients, setCheckedIngredients] = useState<Record<number, boolean>>({});
  const [completedSteps, setCompletedSteps] = useState<Record<number, boolean>>({});
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    loadRecipe();
  }, [recipeId]);

  const loadRecipe = () => {
    setRecipe(recipeService.getById(recipeId));
  };

  if (!recipe) {
    return (
      <div className="p-6 text-center">
        <p className="text-slate-500 mb-4">Receta no encontrada.</p>
        <IonButton onClick={onBack}>Regresar al Recetario</IonButton>
      </div>
    );
  }

  const handleToggleFavorite = () => {
    const updated = recipeService.toggleFavorite(recipe.id);
    if (updated) {
      setRecipe({ ...updated });
      const isFav = updated.favorite || updated.isFavorite;
      setToastMessage(isFav ? 'Guardada en Favoritas' : 'Removida de Favoritas');
    }
  };

  const toggleIngredient = (idx: number) => {
    setCheckedIngredients(prev => ({ ...prev, [idx]: !prev[idx] }));
  };

  const toggleStep = (idx: number) => {
    setCompletedSteps(prev => ({ ...prev, [idx]: !prev[idx] }));
  };

  const handleDelete = () => {
    const titleVal = recipe.name || recipe.title;
    if (window.confirm(`¿Eliminar la receta "${titleVal}"?`)) {
      recipeService.delete(recipe.id);
      onBack();
    }
  };

  const isFavorite = recipe.favorite || recipe.isFavorite;
  const recipeTitle = recipe.name || recipe.title;
  const prepMinutes = recipe.minutes ?? recipe.prepTime ?? 15;

  return (
    <div className="flex flex-col min-h-full pb-12 bg-slate-50">
      <IonHeader>
        <IonToolbar color="primary">
          <IonButtons slot="start">
            <IonBackButton onClick={onBack} text="Volver" />
          </IonButtons>
          <IonTitle>Detalle de Receta</IonTitle>
          <IonButtons slot="end">
            <button
              onClick={handleToggleFavorite}
              className="p-1.5 text-white hover:text-rose-200 rounded-lg hover:bg-white/10 cursor-pointer"
              title="Favorita"
            >
              <Heart className={`w-5 h-5 ${isFavorite ? 'fill-rose-400 text-rose-400' : ''}`} />
            </button>
            <button
              onClick={handleDelete}
              className="p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-white/10 cursor-pointer"
              title="Eliminar"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </IonButtons>
        </IonToolbar>
      </IonHeader>

      <div className="p-4 space-y-4 max-w-lg mx-auto w-full">
        {/* Main cover banner */}
        <div className="relative rounded-2xl overflow-hidden h-48 bg-slate-200 shadow-sm border border-slate-200">
          <img 
            src={recipe.imageUrl} 
            alt={recipeTitle}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex items-end p-4">
            <div className="text-white flex-1">
              <span className="text-[11px] font-bold uppercase tracking-wider bg-amber-500 text-slate-900 px-2.5 py-0.5 rounded-md">
                {recipe.category}
              </span>
              <h1 className="font-extrabold text-xl text-white mt-1 leading-tight">{recipeTitle}</h1>
            </div>
          </div>
        </div>

        {/* Quick stats grid */}
        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-xs">
            <Clock className="w-4 h-4 text-blue-500 mx-auto mb-1" />
            <span className="text-slate-400 block text-[10px]">Preparación</span>
            <span className="font-bold text-slate-800">{prepMinutes} min</span>
          </div>

          <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-xs">
            <Flame className="w-4 h-4 text-rose-500 mx-auto mb-1" />
            <span className="text-slate-400 block text-[10px]">Calorías</span>
            <span className="font-bold text-slate-800">{recipe.calories} kcal</span>
          </div>

          <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-xs">
            <Users className="w-4 h-4 text-emerald-500 mx-auto mb-1" />
            <span className="text-slate-400 block text-[10px]">Porciones</span>
            <span className="font-bold text-slate-800">{recipe.servings} pers</span>
          </div>
        </div>

        {/* Ingredients Section */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider text-slate-500 flex items-center gap-2">
              <ChefHat className="w-4 h-4 text-amber-500" />
              Ingredientes ({recipe.ingredients.length})
            </h3>
            <span className="text-[11px] text-slate-400 font-semibold">Toca para tachar</span>
          </div>

          <div className="space-y-2 text-xs">
            {recipe.ingredients.map((ing, idx) => {
              const isChecked = checkedIngredients[idx];
              return (
                <div 
                  key={idx}
                  onClick={() => toggleIngredient(idx)}
                  className={`flex items-center gap-2.5 p-2.5 rounded-xl cursor-pointer transition-colors ${
                    isChecked ? 'bg-emerald-50 text-emerald-800 line-through' : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {isChecked ? (
                    <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <Square className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                  <span className="flex-1 font-medium">{ing}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Step-by-Step Instructions */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs space-y-3">
          <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider text-slate-500 border-b border-slate-100 pb-2 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-500" />
            Paso a Paso
          </h3>

          <div className="space-y-3 text-xs">
            {recipe.instructions.map((step, idx) => {
              const isDone = completedSteps[idx];
              return (
                <div 
                  key={idx}
                  onClick={() => toggleStep(idx)}
                  className={`p-3 rounded-xl border transition-all cursor-pointer ${
                    isDone 
                      ? 'bg-blue-50/60 border-blue-200 text-blue-900' 
                      : 'bg-slate-50 border-slate-200/70 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] ${
                      isDone ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-600'
                    }`}>
                      {idx + 1}
                    </span>
                    <span className="font-bold text-slate-800">Paso {idx + 1}</span>
                    {isDone && <span className="text-[10px] font-bold text-blue-600 ml-auto">Completado ✓</span>}
                  </div>
                  <p className="pl-7 leading-relaxed">{step}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <IonToast
        isOpen={!!toastMessage}
        message={toastMessage || ''}
        onDidDismiss={() => setToastMessage(null)}
      />
    </div>
  );
};
