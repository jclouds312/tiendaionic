export interface Book {
  id: string;
  title: string;
  author: string;
  read: boolean;
  genre?: string;
  rating?: number;
  coverUrl?: string;
  description?: string;
  publishYear?: number;
  totalPages?: number;
  addedAt?: string;
}

export type BookFilter = 'all' | 'read' | 'unread';
