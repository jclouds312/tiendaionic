export type SuggestionCategory = 'Infraestructura' | 'Servicio al Cliente' | 'Académico' | 'Tecnología' | 'Otros';
export type SuggestionStatus = 'Pendiente' | 'En Revisión' | 'Aprobada' | 'Rechazada';

export interface Suggestion {
  id: string;
  title: string;
  category: SuggestionCategory;
  description: string;
  rating: number; // 1 to 5 stars
  status: SuggestionStatus;
  createdAt: string;
  authorName: string;
  email: string;
  responseNote?: string;
}

export interface SuggestionFormData {
  title: string;
  category: SuggestionCategory;
  description: string;
  rating: number;
  authorName: string;
  email: string;
}
