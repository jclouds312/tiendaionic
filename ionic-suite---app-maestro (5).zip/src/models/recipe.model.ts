export interface Recipe {
  id: string;
  name: string;
  title: string;
  category: 'Desayunos' | 'Almuerzos' | 'Cenas' | 'Postres' | 'Bebidas' | 'Ensaladas';
  minutes: number;
  prepTime: number; // in minutes
  favorite: boolean;
  isFavorite: boolean;
  ingredients: string[];
  instructions: string[];
  imageUrl: string;
  difficulty: 'Fácil' | 'Media' | 'Avanzada';
  calories: number;
  servings: number;
  createdAt?: string;
}

export type RecipeCategoryFilter = 'Todas' | 'Favoritas' | 'Desayunos' | 'Almuerzos' | 'Cenas' | 'Postres';
