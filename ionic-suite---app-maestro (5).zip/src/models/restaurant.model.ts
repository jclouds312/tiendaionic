export interface MenuItem {
  id: string;
  name: string;
  price: number;
  description: string;
  category: string;
  isPopular?: boolean;
}

export interface Restaurant {
  id: string;
  name: string;
  category: 'Mariscos' | 'Italiana' | 'Mexicana' | 'Cafés' | 'Internacional' | 'Cortes';
  rating: number;
  favorite: boolean;
  isFavorite?: boolean;
  address: string;
  phone: string;
  imageUrl: string;
  priceRange: '$' | '$$' | '$$$' | '$$$$';
  schedule: string;
  description: string;
  menu: MenuItem[];
}

export type RestaurantCategoryFilter = 'Todos' | 'Favoritos' | 'Mariscos' | 'Italiana' | 'Mexicana' | 'Cafés' | 'Internacional';
