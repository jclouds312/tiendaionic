# Suite Multiproyecto Ionic 8 Standalone - Academic Architecture

Este repositorio contiene la estructura completa para el desarrollo de las 4 Guías Académicas de Aprendizaje:

1. **Proyecto 1: Catálogo de Libros (Book App)** - Gestión de lectura, ratings y estado de libros.
2. **Proyecto 2: Catálogo de Restaurantes (Restaurant App)** - Listado interactivo, menús reactivos y modales.
3. **Proyecto 3: Catálogo de Recetas (Recipe App)** - Favoritos, ingredientes y vista de detalles.
4. **Proyecto 4: Buzón de Sugerencias (Suggestion App)** - Formularios reactivos y elementos deslizables (IonItemSliding).

## Estructura de Directorios

```
src/
├── assets/          # Recursos estáticos (imágenes, iconos, fuentes)
├── components/      # Componentes UI reutilizables
│   └── shared/      # Librería de componentes Ionic UI Standalone y MobileFrame
├── environments/    # Configuración de entornos de ejecución
├── interfaces/      # Interfaces de TypeScript para contratos estrictos
├── models/          # Modelos de datos de la aplicación
├── pages/           # Vistas principales de los 4 proyectos
│   ├── books/
│   ├── recipes/
│   ├── restaurants/
│   └── suggestions/
├── services/        # Servicios inyectables (providedIn: 'root')
└── theme/           # Estilos globales y tokens del tema Ionic Clean Minimalism
```

## Instrucciones de Inicio

```bash
# Instalación de dependencias
npm install

# Iniciar servidor de desarrollo
npm run dev

# Compilar proyecto
npm run build
```
