# Suite Multiproyecto Ionic 8 Standalone - Academic Architecture

> **Desarrollado por Owen Phillips** - *Lead Developer & Ionic Expert*

Este repositorio contiene la estructura completa para el desarrollo de las 4 Guías Académicas de Aprendizaje:

1. **Proyecto 1: Catálogo de Libros (Book App)** - Gestión de lectura, ratings, estado de libros, sistema de favoritos, ordenamiento (alfabético/fecha) y búsqueda en tiempo real.
2. **Proyecto 2: Catálogo de Restaurantes (Restaurant App)** - Listado interactivo, menús reactivos y modales.
3. **Proyecto 3: Catálogo de Recetas (Recipe App)** - Favoritos, búsqueda por nombre o ingrediente, ordenamiento (alfabético/fecha/tiempo/calorías) y vista de detalles.
4. **Proyecto 4: Buzón de Sugerencias (Suggestion App)** - Formularios reactivos con **validaciones visuales dinámicas** y elementos deslizables (IonItemSliding).

## Novedades y Funcionalidades Recientes

- **🌙 Botón de Conmutación de Tema Global (Modo Claro / Modo Oscuro)**:
  - Botón selector en el encabezado global de `MobileFrame` con iconos dinámicos de Sol y Luna (`Sun` / `Moon`).
  - Sincronización mediante variables CSS de Tailwind y clase raíz `.dark`.
  - Persistencia automática de la preferencia del usuario en `localStorage` (`app-theme`).
  - Adaptación completa de marcos, cajón lateral de navegación (Drawer) y componentes a la paleta de colores.

- **👆 Gestos Táctiles Deslizables (Swipe-to-Delete) en Favoritos**:
  - Componente de interacción táctil móvil `SwipeableItem` con soporte para gestos `onTouch` y arrastre de mouse.
  - Desplazamiento horizontal fluido de tarjetas en las listas de Favoritos de **Libros** y **Recetas**.
  - Revelado de acción posterior animada en color rojo para **Quitar de Favoritos** o **Eliminar**.
  - Umbral de deslizamiento rápido (swipe completo) que ejecuta automáticamente la remoción con mensaje toast.
  - Indicadores visuales e instrucciones claras ("Desliza a la izquierda para quitar de Favoritos").

- **⏱️ Estimación de Tiempo de Lectura y Rastreo de Sesión**:
  - Distintivo de **Tiempo Estimado de Lectura** calculado automáticamente según la densidad estimada de palabras (~275 palabras/pág) y velocidad promedio (~220 WPM).
  - Indicadores del tiempo total estimado y tiempo restante pendiente según las páginas no leídas del libro.
  - Cronómetro interactivo de **Tiempo en esta Sesión** con controles de pausa, reanudación y reinicio.

- **📊 Rastreador de Progreso de Lectura**:
  - Barra de progreso interactiva con indicador de porcentaje dinámico en `BookDetailPage`.
  - Controles táctiles paso a paso (`-10`, `-1`, `+1`, `+10`) y deslizador tipo *range slider* para ajustar la página actual.
  - Botones de acceso rápido para "Completar 100%" o "Reiniciar Lectura".
  - Mini barra de progreso visual integrada en las tarjetas del catálogo principal de libros.

- **📶 Persistencia Offline con Service Workers (PWA)**:
  - Registro de Service Worker (`sw.js`) para el almacenamiento en caché del App Shell y recursos multimedia.
  - Estrategia de **Cache-First** para imágenes portadas de libros, fotografías de restaurantes y platillos de recetas para garantizar su visibilidad en modo offline.
  - Estrategia de **Network-First / Stale-While-Revalidate** para documentos y scripts.
  - Indicador visual interactivo de estado de red (`Online` / `Modo Offline (SW)`) en la barra de estado superior y en la barra lateral.

- **📋 Validaciones Visuales en Formularios de Sugerencias**:
  - Barra de progreso reactiva indicando el número de campos completados (0/4 a 4/4).
  - Indicadores visuales de éxito (`✓ Correcto`) y alerta (`⚠️ Error`) por campo.
  - Mensajes de error contextuados por longitud mínima (título, descripción, emisor) y formato de correo electrónico (`Regex`).
  - Habilitación dinámica del botón de envío según validez total.

- **❤️ Botón de Favoritos con Persistencia Local**:
  - Permite marcar y desmarcar libros y recetas como favoritos individualmente.
  - Sincronización automática y almacenamiento permanente en `book.service.ts` y `recipe.service.ts` (`localStorage`).
  - Pestañas/Filtros dedicados a Favoritos en las pantallas principales.

- **🔍 Búsqueda en Tiempo Real con Indicadores**:
  - Filtrado reactivo en libros por **título, autor o género**.
  - Filtrado reactivo en recetas por **nombre, categoría o ingredientes**.
  - Contador dinámico de coincidencias y botón rápido para limpiar búsqueda.

- **🔤 Componentes Dropdown de Ordenamiento**:
  - Selector desplegable para ordenar libros por **fecha (recientes/antiguos)**, **alfabéticamente (A-Z/Z-A)** y **mayor valoración**.
  - Selector desplegable para ordenar recetas por **fecha**, **nombre (A-Z/Z-A)**, **tiempo de preparación** y **calorías**.

- **🛡️ ErrorBoundary & Tolerancia a Fallos**:
  - Componente de captura de errores inesperados con opción de recarga e información de diagnóstico.

## Estructura de Directorios

```
src/
├── assets/          # Recursos estáticos (imágenes, iconos, fuentes)
├── components/      # Componentes UI reutilizables
│   └── shared/      # Librería de componentes Ionic UI Standalone, ErrorBoundary y MobileFrame
├── environments/    # Configuración de entornos de ejecución
├── interfaces/      # Interfaces de TypeScript para contratos strictly typed
├── models/          # Modelos de datos de la aplicación
├── pages/           # Vistas principales de los 4 proyectos
│   ├── books/
│   ├── recipes/
│   ├── restaurants/
│   └── suggestions/
├── services/        # Servicios inyectables (providedIn: 'root') con persistencia
└── theme/           # Estilos globales y tokens del tema Ionic Clean Minimalism
```

## Instrucciones de Inicio

```bash
# Instalación de dependencias
npm install

# Iniciar servidor de desarrollo
npm run dev

# Validar tipos y TypeScript
npm run lint

# Compilar proyecto para producción
npm run build
```

## Despliegue en Vercel (Zero Config)

El proyecto incluye la configuración requerida (`vercel.json`) para un despliegue automático y fluido en Vercel:

1. Subir/Importar este repositorio en tu cuenta de **Vercel**.
2. Framework Preset: **Vite** (detectado automáticamente).
3. Build Command: `npm run build`
4. Output Directory: `dist`
5. Configuración de reescritura SPA lista en `vercel.json`.
6. Haz clic en **Deploy**.

