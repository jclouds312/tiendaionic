export interface Book {
  id: string;
  title: string;
  author: string;
  read: boolean;
  favorite?: boolean;
  genre?: string;
  rating?: number;
  coverUrl?: string;
  description?: string;
  publishYear?: number;
  totalPages?: number;
  currentPage?: number;
  addedAt?: string;
}

export type BookFilter = 'all' | 'favorites' | 'read' | 'unread';
