import React, { useState } from 'react';
import { SuggestionCategory, SuggestionFormData } from '../../models/suggestion.model';
import { suggestionService } from '../../services/suggestion.service';
import { 
  IonModal, 
  IonButton, 
  StarRating 
} from '../../components/shared/IonicUI';
import { AlertCircle, CheckCircle2, Mail, User, Tag, FileText } from 'lucide-react';

interface NewSuggestionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuggestionCreated: () => void;
}

export const NewSuggestionModal: React.FC<NewSuggestionModalProps> = ({
  isOpen,
  onClose,
  onSuggestionCreated
}) => {
  // Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<SuggestionCategory>('Infraestructura');
  const [description, setDescription] = useState('');
  const [rating, setRating] = useState(5);
  const [authorName, setAuthorName] = useState('');
  const [email, setEmail] = useState('');

  // Touched state trackers for reactive validation
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const handleBlur = (field: string) => {
    setTouched(prev => ({ ...prev, [field]: true }));
  };

  // Validation rules
  const isTitleValid = title.trim().length >= 5;
  const isDescriptionValid = description.trim().length >= 15;
  const isAuthorValid = authorName.trim().length >= 3;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const isEmailValid = emailRegex.test(email);

  const completedCount = [isTitleValid, isDescriptionValid, isAuthorValid, isEmailValid].filter(Boolean).length;
  const isFormValid = completedCount === 4;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFormValid) {
      setTouched({ title: true, description: true, authorName: true, email: true });
      return;
    }

    const newFormData: SuggestionFormData = {
      title: title.trim(),
      category,
      description: description.trim(),
      rating,
      authorName: authorName.trim(),
      email: email.trim()
    };

    suggestionService.add(newFormData);
    onSuggestionCreated();
    resetForm();
    onClose();
  };

  const resetForm = () => {
    setTitle('');
    setCategory('Infraestructura');
    setDescription('');
    setRating(5);
    setAuthorName('');
    setEmail('');
    setTouched({});
  };

  return (
    <IonModal isOpen={isOpen} onDidDismiss={onClose} title="Enviar Nueva Sugerencia">
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Visual Progress Indicator */}
        <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className="flex items-center gap-1.5 text-slate-700">
              <FileText className="w-3.5 h-3.5 text-blue-600" />
              <span>Progreso del formulario *</span>
            </span>
            <span className={`text-[11px] px-2 py-0.5 rounded-full font-bold ${
              isFormValid ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
            }`}>
              {completedCount} de 4 campos requeridos
            </span>
          </div>

          <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all duration-300 ${
                completedCount === 4 ? 'bg-emerald-500' : completedCount >= 2 ? 'bg-amber-500' : 'bg-blue-500'
              }`}
              style={{ width: `${(completedCount / 4) * 100}%` }}
            />
          </div>

          {!isFormValid && (Object.keys(touched).length > 0) && (
            <div className="text-[11px] text-rose-600 flex items-center gap-1 font-medium pt-0.5">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>Completa los campos obligatorios marcados para habilitar el envío.</span>
            </div>
          )}
        </div>

        {/* Title input with validation */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1 flex items-center justify-between">
            <span>Título de la Sugerencia *</span>
            <span className="text-[10px] text-slate-400 font-normal">
              {title.trim().length}/5 mín.
            </span>
          </label>
          <div className="relative">
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              onBlur={() => handleBlur('title')}
              placeholder="Ej: Ampliación de horarios de laboratorio"
              className={`w-full px-3 py-2 pr-8 bg-slate-50 border rounded-xl text-sm focus:outline-hidden transition-all ${
                touched.title 
                  ? isTitleValid 
                    ? 'border-emerald-500 bg-emerald-50/20 text-slate-900' 
                    : 'border-rose-500 bg-rose-50/20 text-rose-900' 
                  : 'border-slate-200 focus:ring-2 focus:ring-blue-500/30'
              }`}
            />
            {touched.title && (
              <div className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none">
                {isTitleValid ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-500" />
                )}
              </div>
            )}
          </div>
          {touched.title && !isTitleValid && (
            <p className="mt-1 text-[11px] text-rose-600 font-medium flex items-center gap-1">
              <AlertCircle className="w-3 h-3" /> Debe tener al menos 5 caracteres.
            </p>
          )}
        </div>

        {/* Category & Rating */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Categoría
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as SuggestionCategory)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30 font-medium"
            >
              <option value="Infraestructura">Infraestructura</option>
              <option value="Servicio al Cliente">Servicio al Cliente</option>
              <option value="Académico">Académico</option>
              <option value="Tecnología">Tecnología</option>
              <option value="Otros">Otros</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Calificación Servicio
            </label>
            <StarRating value={rating} onChange={setRating} size="md" />
          </div>
        </div>

        {/* Description Input */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1 flex items-center justify-between">
            <span>Descripción Detallada *</span>
            <span className="text-[10px] text-slate-400 font-normal">
              {description.trim().length}/15 mín.
            </span>
          </label>
          <div className="relative">
            <textarea
              rows={3}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              onBlur={() => handleBlur('description')}
              placeholder="Explica detalladamente la propuesta o aspecto a mejorar..."
              className={`w-full px-3 py-2 bg-slate-50 border rounded-xl text-sm focus:outline-hidden transition-all ${
                touched.description 
                  ? isDescriptionValid 
                    ? 'border-emerald-500 bg-emerald-50/20 text-slate-900' 
                    : 'border-rose-500 bg-rose-50/20 text-rose-900' 
                  : 'border-slate-200 focus:ring-2 focus:ring-blue-500/30'
              }`}
            />
          </div>
          {touched.description && !isDescriptionValid && (
            <p className="mt-1 text-[11px] text-rose-600 font-medium flex items-center gap-1">
              <AlertCircle className="w-3 h-3" /> Debe contener al menos 15 caracteres descriptivos.
            </p>
          )}
        </div>

        {/* Author Name */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1 flex items-center justify-between">
            <span>Nombre del Emisor *</span>
            <span className="text-[10px] text-slate-400 font-normal">
              Mín. 3 letras
            </span>
          </label>
          <div className="relative">
            <input
              type="text"
              required
              value={authorName}
              onChange={(e) => setAuthorName(e.target.value)}
              onBlur={() => handleBlur('authorName')}
              placeholder="Ej: Carlos Mendoza"
              className={`w-full px-3 py-2 pr-8 bg-slate-50 border rounded-xl text-sm focus:outline-hidden transition-all ${
                touched.authorName 
                  ? isAuthorValid 
                    ? 'border-emerald-500 bg-emerald-50/20 text-slate-900' 
                    : 'border-rose-500 bg-rose-50/20 text-rose-900' 
                  : 'border-slate-200 focus:ring-2 focus:ring-blue-500/30'
              }`}
            />
            {touched.authorName && (
              <div className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none">
                {isAuthorValid ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-500" />
                )}
              </div>
            )}
          </div>
          {touched.authorName && !isAuthorValid && (
            <p className="mt-1 text-[11px] text-rose-600 font-medium flex items-center gap-1">
              <AlertCircle className="w-3 h-3" /> Nombre obligatorio (mínimo 3 caracteres).
            </p>
          )}
        </div>

        {/* Email with Regex Validation */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1 flex items-center justify-between">
            <span>Correo Electrónico *</span>
            <span className="text-[10px] text-slate-400 font-normal">
              Formato de email
            </span>
          </label>
          <div className="relative">
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onBlur={() => handleBlur('email')}
              placeholder="carlos.mendoza@alumnos.edu.mx"
              className={`w-full px-3 py-2 pr-8 bg-slate-50 border rounded-xl text-sm focus:outline-hidden transition-all ${
                touched.email 
                  ? isEmailValid 
                    ? 'border-emerald-500 bg-emerald-50/20 text-slate-900' 
                    : 'border-rose-500 bg-rose-50/20 text-rose-900' 
                  : 'border-slate-200 focus:ring-2 focus:ring-blue-500/30'
              }`}
            />
            {touched.email && (
              <div className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none">
                {isEmailValid ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-500" />
                )}
              </div>
            )}
          </div>
          {touched.email && !isEmailValid && (
            <p className="mt-1 text-[11px] text-rose-600 font-medium flex items-center gap-1">
              <AlertCircle className="w-3 h-3" /> Formato de correo electrónico inválido (ejemplo: usuario@correo.com).
            </p>
          )}
        </div>

        {/* Developer Credit Footer Badge */}
        <div className="pt-2 text-[11px] text-slate-400 text-center border-t border-slate-100 flex items-center justify-between">
          <span className="font-semibold text-slate-500">Desarrollo por Owen Phillips</span>
          <span className="text-slate-400">Validación reactiva v2.0</span>
        </div>

        <div className="pt-2 flex justify-end gap-2">
          <IonButton fill="clear" color="medium" onClick={onClose}>
            Cancelar
          </IonButton>
          <IonButton type="submit" color="primary" disabled={!isFormValid}>
            Enviar Sugerencia
          </IonButton>
        </div>
      </form>
    </IonModal>
  );
};
