import React, { useState, useEffect } from 'react';
import { Book } from '../../models/book.model';
import { bookService } from '../../services/book.service';
import { 
  IonHeader, 
  IonToolbar, 
  IonTitle, 
  IonButtons, 
  IonBackButton, 
  IonButton, 
  IonBadge, 
  IonToast,
  StarRating
} from '../../components/shared/IonicUI';
import { 
  BookOpen, 
  CheckCircle2, 
  Circle, 
  Calendar, 
  FileText, 
  Trash2, 
  Bookmark,
  Share2,
  Heart,
  TrendingUp,
  Plus,
  Minus,
  RotateCcw,
  Sparkles,
  Clock,
  Timer,
  Pause,
  Play,
  Hourglass
} from 'lucide-react';

interface BookDetailPageProps {
  bookId: string;
  onBack: () => void;
}

export const BookDetailPage: React.FC<BookDetailPageProps> = ({ bookId, onBack }) => {
  const [book, setBook] = useState<Book | undefined>(undefined);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [sessionSeconds, setSessionSeconds] = useState<number>(0);
  const [isTimerActive, setIsTimerActive] = useState<boolean>(true);

  useEffect(() => {
    loadBook();
  }, [bookId]);

  useEffect(() => {
    let interval: NodeJS.Timeout | undefined;
    if (isTimerActive) {
      interval = setInterval(() => {
        setSessionSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerActive]);

  const formatSeconds = (totalSec: number): string => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const loadBook = () => {
    setBook(bookService.getById(bookId));
  };

  if (!book) {
    return (
      <div className="p-6 text-center">
        <p className="text-slate-500 mb-4">Libro no encontrado.</p>
        <IonButton onClick={onBack}>Regresar al Catálogo</IonButton>
      </div>
    );
  }

  const totalPages = book.totalPages || 100;
  const currentPage = book.currentPage ?? (book.read ? totalPages : 0);
  const progressPercent = Math.min(100, Math.max(0, Math.round((currentPage / totalPages) * 100)));

  // Estimated reading time based on page count and standard word density (~275 words/page, ~220 WPM)
  const WORDS_PER_PAGE = 275;
  const WORDS_PER_MINUTE = 220;
  const totalWordCount = totalPages * WORDS_PER_PAGE;
  const totalEstMinutes = Math.ceil(totalWordCount / WORDS_PER_MINUTE);
  const remainingPages = Math.max(0, totalPages - currentPage);
  const remainingEstMinutes = Math.ceil((remainingPages * WORDS_PER_PAGE) / WORDS_PER_MINUTE);

  const formatEstTime = (totalMins: number): string => {
    if (totalMins < 60) return `${totalMins} min`;
    const hours = Math.floor(totalMins / 60);
    const mins = totalMins % 60;
    return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
  };

  const handleUpdatePage = (newPage: number) => {
    const updated = bookService.updateReadingProgress(book.id, newPage);
    if (updated) {
      setBook({ ...updated });
      if (updated.read && newPage >= totalPages) {
        setToastMessage('🎉 ¡Felicitaciones! Has completado este libro.');
      } else {
        setToastMessage(`Progreso actualizado a pág. ${updated.currentPage} (${Math.round((updated.currentPage! / totalPages) * 100)}%)`);
      }
    }
  };

  const handleToggleRead = () => {
    const updated = bookService.toggleRead(book.id);
    if (updated) {
      setBook({ ...updated });
      setToastMessage(updated.read ? 'Libro marcado como Leído (100%)' : 'Libro marcado como Pendiente');
    }
  };

  const handleToggleFavorite = () => {
    const updated = bookService.toggleFavorite(book.id);
    if (updated) {
      setBook({ ...updated });
      setToastMessage(updated.favorite ? '⭐ Guardado en Favoritos' : 'Removido de Favoritos');
    }
  };

  const handleDelete = () => {
    if (window.confirm(`¿Seguro que deseas eliminar "${book.title}"?`)) {
      bookService.delete(book.id);
      onBack();
    }
  };

  return (
    <div className="flex flex-col min-h-full pb-10 bg-slate-50">
      <IonHeader>
        <IonToolbar color="primary">
          <IonButtons slot="start">
            <IonBackButton onClick={onBack} text="Volver" />
          </IonButtons>
          <IonTitle>Detalle del Libro</IonTitle>
          <IonButtons slot="end">
            <button 
              onClick={handleDelete}
              className="p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-white/10"
              title="Eliminar"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </IonButtons>
        </IonToolbar>
      </IonHeader>

      <div className="p-4 space-y-4 max-w-lg mx-auto w-full">
        {/* Cover Hero Banner */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs flex flex-col items-center text-center">
          {book.coverUrl ? (
            <img 
              src={book.coverUrl} 
              alt={book.title} 
              className="w-36 h-52 object-cover rounded-xl shadow-md mb-4 bg-slate-100"
            />
          ) : (
            <div className="w-36 h-52 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center mb-4 shadow-inner">
              <Bookmark className="w-16 h-16" />
            </div>
          )}

          <IonBadge color={book.read ? 'success' : 'warning'} className="mb-2">
            {book.read ? '✓ Estado: Leído' : '⏳ Estado: Pendiente de Lectura'}
          </IonBadge>

          <h1 className="font-extrabold text-slate-800 text-xl tracking-tight leading-tight">{book.title}</h1>
          <p className="text-sm font-semibold text-blue-600 mt-1">Autor: {book.author}</p>

          {book.genre && (
            <span className="mt-2 text-xs font-semibold px-3 py-1 bg-slate-100 text-slate-600 rounded-full">
              {book.genre}
            </span>
          )}

          {book.rating && (
            <div className="mt-2.5 flex items-center gap-2">
              <StarRating value={book.rating} readOnly size="md" />
              <span className="text-xs font-bold text-slate-700">({book.rating} / 5 estrellas)</span>
            </div>
          )}

          {/* Estimated Reading Time Badge */}
          <div className="mt-3.5 flex flex-wrap items-center justify-center gap-1.5">
            <span className="inline-flex items-center gap-1 text-xs font-bold px-3 py-1 bg-amber-50 text-amber-800 border border-amber-200/80 rounded-full shadow-2xs">
              <Clock className="w-3.5 h-3.5 text-amber-600" />
              <span>Lectura est.: ~{formatEstTime(totalEstMinutes)}</span>
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2.5 py-1 bg-slate-100 text-slate-600 rounded-full">
              <FileText className="w-3 h-3 text-slate-400" />
              <span>~{totalWordCount.toLocaleString()} palabras</span>
            </span>
          </div>

          <div className="mt-5 w-full flex items-center gap-2">
            <IonButton 
              onClick={handleToggleRead} 
              color={book.read ? 'medium' : 'success'}
              className="flex-1"
            >
              {book.read ? (
                <>
                  <Circle className="w-4 h-4 mr-2" /> Marcar Pendiente
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4 mr-2" /> Marcar Como Leído
                </>
              )}
            </IonButton>

            <button
              onClick={handleToggleFavorite}
              className={`p-3 rounded-xl border font-semibold transition-all flex items-center justify-center cursor-pointer active:scale-95 ${
                book.favorite 
                  ? 'bg-rose-50 border-rose-200 text-rose-600' 
                  : 'bg-slate-50 border-slate-200 text-slate-500 hover:text-rose-600'
              }`}
              title={book.favorite ? 'Remover de Favoritos' : 'Añadir a Favoritos'}
            >
              <Heart className={`w-5 h-5 ${book.favorite ? 'fill-rose-600' : ''}`} />
            </button>
          </div>
        </div>

        {/* Time Spent & Estimated Reading Time Card */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
            <div className="flex items-center gap-2">
              <Timer className="w-4 h-4 text-amber-600" />
              <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider">
                Tiempo de Lectura y Estimación
              </h3>
            </div>
            <span className="flex items-center gap-1 text-[11px] font-semibold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full">
              <Hourglass className="w-3 h-3 text-amber-600" /> ~220 ppm
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Box 1: Estimated Reading Times */}
            <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200/70 space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-600">
                <span>Tiempo Total Estimado</span>
                <span className="font-bold text-amber-700 bg-amber-100/80 px-2 py-0.5 rounded text-[11px]">
                  ~{formatEstTime(totalEstMinutes)}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs font-semibold text-slate-600">
                <span>Tiempo Restante Pendiente</span>
                <span className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                  remainingEstMinutes === 0 
                    ? 'text-emerald-700 bg-emerald-100' 
                    : 'text-blue-700 bg-blue-100'
                }`}>
                  {remainingEstMinutes === 0 ? '✓ 0 min' : `~${formatEstTime(remainingEstMinutes)}`}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 pt-1 border-t border-slate-200/50">
                Calculado sobre ~{totalWordCount.toLocaleString()} palabras ({totalPages} págs).
              </p>
            </div>

            {/* Box 2: Time Spent in Current Session */}
            <div className="bg-slate-900 text-white rounded-xl p-3.5 border border-slate-800 flex flex-col justify-between space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${isTimerActive ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                  Tiempo en esta Sesión
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  {isTimerActive ? 'Activo' : 'Pausado'}
                </span>
              </div>

              <div className="flex items-baseline justify-between">
                <span className="text-2xl font-mono font-black tracking-tight text-emerald-400">
                  {formatSeconds(sessionSeconds)}
                </span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setIsTimerActive(!isTimerActive)}
                    className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-all"
                    title={isTimerActive ? 'Pausar cronómetro' : 'Reanudar cronómetro'}
                  >
                    {isTimerActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    onClick={() => setSessionSeconds(0)}
                    className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 rounded-lg transition-all"
                    title="Reiniciar tiempo de sesión"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <p className="text-[10px] text-slate-400 italic">
                {sessionSeconds > 300 
                  ? '🔥 ¡Gran sesión de lectura acumulada!' 
                  : sessionSeconds > 60 
                    ? '📖 Lectura en progreso...' 
                    : '⏱️ Registro de tiempo iniciado.'}
              </p>
            </div>
          </div>
        </div>

        {/* Read Progress Tracker Card */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-blue-600" />
              <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider">
                Progreso de Lectura
              </h3>
            </div>
            <span className={`text-xs font-extrabold px-2.5 py-1 rounded-full ${
              progressPercent === 100 
                ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
                : progressPercent > 0 
                  ? 'bg-blue-100 text-blue-800 border border-blue-200' 
                  : 'bg-slate-100 text-slate-600'
            }`}>
              {progressPercent === 100 ? '🎉 Completado 100%' : `${progressPercent}% avance`}
            </span>
          </div>

          {/* Progress Bar */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs font-semibold text-slate-600">
              <span>Página <strong className="text-blue-600 font-extrabold text-sm">{currentPage}</strong> de {totalPages}</span>
              <span className="text-slate-400 font-mono text-[11px]">{progressPercent}%</span>
            </div>
            <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200/60 shadow-inner">
              <div 
                className={`h-full rounded-full transition-all duration-300 ${
                  progressPercent === 100 
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-400' 
                    : 'bg-gradient-to-r from-blue-600 to-indigo-500'
                }`}
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Interactive Range Slider */}
          <div className="space-y-1">
            <input 
              type="range"
              min={0}
              max={totalPages}
              value={currentPage}
              onChange={(e) => handleUpdatePage(Number(e.target.value))}
              className="w-full accent-blue-600 h-2 bg-slate-200 rounded-lg cursor-pointer"
            />
          </div>

          {/* Quick Page Steppers */}
          <div className="flex flex-wrap items-center justify-between gap-1.5 pt-1">
            <div className="flex items-center gap-1">
              <button
                onClick={() => handleUpdatePage(currentPage - 10)}
                disabled={currentPage <= 0}
                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-700 rounded-lg text-xs font-bold transition-all"
                title="Retroceder 10 páginas"
              >
                -10
              </button>
              <button
                onClick={() => handleUpdatePage(currentPage - 1)}
                disabled={currentPage <= 0}
                className="p-1.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-700 rounded-lg transition-all"
                title="Retroceder 1 página"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => handleUpdatePage(currentPage + 1)}
                disabled={currentPage >= totalPages}
                className="p-1.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-700 rounded-lg transition-all"
                title="Avanzar 1 página"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => handleUpdatePage(currentPage + 10)}
                disabled={currentPage >= totalPages}
                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-700 rounded-lg text-xs font-bold transition-all"
                title="Avanzar 10 páginas"
              >
                +10
              </button>
            </div>

            <div className="flex items-center gap-1.5">
              {currentPage > 0 && (
                <button
                  onClick={() => handleUpdatePage(0)}
                  className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all"
                >
                  <RotateCcw className="w-3 h-3" /> Reiniciar
                </button>
              )}
              {progressPercent < 100 && (
                <button
                  onClick={() => handleUpdatePage(totalPages)}
                  className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs transition-all"
                >
                  <Sparkles className="w-3 h-3" /> 100%
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Metadata Details Grid */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs space-y-3">
          <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider text-slate-400 border-b border-slate-100 pb-2">
            Información Técnica
          </h3>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="flex items-center gap-2.5 p-2.5 bg-slate-50 rounded-xl">
              <Calendar className="w-4 h-4 text-blue-500 shrink-0" />
              <div>
                <span className="text-slate-400 block">Año Publicación</span>
                <span className="font-bold text-slate-700">{book.publishYear || 'N/A'}</span>
              </div>
            </div>

            <div className="flex items-center gap-2.5 p-2.5 bg-slate-50 rounded-xl">
              <FileText className="w-4 h-4 text-emerald-500 shrink-0" />
              <div>
                <span className="text-slate-400 block">Total Páginas</span>
                <span className="font-bold text-slate-700">{book.totalPages || 'N/A'} págs</span>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">
              Sinopsis
            </span>
            <p className="text-sm text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
              {book.description || 'No se ha agregado una descripción formal para este título.'}
            </p>
          </div>
        </div>
      </div>

      <IonToast
        isOpen={!!toastMessage}
        message={toastMessage || ''}
        onDidDismiss={() => setToastMessage(null)}
      />
    </div>
  );
};
