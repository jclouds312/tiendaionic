import React, { useState, useEffect } from 'react';
import { Book, BookFilter } from '../../models/book.model';
import { bookService } from '../../services/book.service';
import { EmptyState } from '../../components/shared/EmptyState';
import { 
  IonHeader, 
  IonToolbar, 
  IonTitle, 
  IonButtons, 
  IonButton, 
  IonCard, 
  IonBadge, 
  IonSegment, 
  IonSegmentButton, 
  IonFab, 
  IonFabButton, 
  IonModal, 
  IonToast,
  StarRating
} from '../../components/shared/IonicUI';
import { 
  BookOpen, 
  Plus, 
  CheckCircle2, 
  Circle, 
  Search, 
  X,
  Trash2, 
  Eye, 
  Bookmark,
  Sparkles,
  Heart,
  ArrowUpDown,
  Info
} from 'lucide-react';
import { SwipeableItem } from '../../components/shared/SwipeableItem';

interface BooksHomePageProps {
  onSelectBook: (bookId: string) => void;
}

export type BookSortOption = 'title-asc' | 'title-desc' | 'date-desc' | 'date-asc' | 'rating-desc';

export const BooksHomePage: React.FC<BooksHomePageProps> = ({ onSelectBook }) => {
  const [books, setBooks] = useState<Book[]>([]);
  const [filter, setFilter] = useState<BookFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<BookSortOption>('date-desc');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form State
  const [newTitle, setNewTitle] = useState('');
  const [newAuthor, setNewAuthor] = useState('');
  const [newGenre, setNewGenre] = useState('Ficción');
  const [newRating, setNewRating] = useState(5);
  const [newPages, setNewPages] = useState(250);
  const [newDescription, setNewDescription] = useState('');

  useEffect(() => {
    refreshBooks();
  }, []);

  const refreshBooks = () => {
    setBooks(bookService.getAll());
  };

  const handleToggleRead = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const updated = bookService.toggleRead(id);
    if (updated) {
      setToastMessage(
        updated.read ? `"${updated.title}" marcado como LEÍDO` : `"${updated.title}" marcado como PENDIENTE`
      );
      refreshBooks();
    }
  };

  const handleToggleFavorite = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const updated = bookService.toggleFavorite(id);
    if (updated) {
      setToastMessage(
        updated.favorite 
          ? `⭐ "${updated.title}" guardado en Favoritos` 
          : `"${updated.title}" removido de Favoritos`
      );
      refreshBooks();
    }
  };

  const handleDeleteBook = (e: React.MouseEvent, id: string, title: string) => {
    e.stopPropagation();
    if (bookService.delete(id)) {
      setToastMessage(`Libro "${title}" eliminado.`);
      refreshBooks();
    }
  };

  const handleAddBook = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newAuthor.trim()) return;

    bookService.add({
      title: newTitle,
      author: newAuthor,
      genre: newGenre,
      rating: newRating,
      totalPages: Number(newPages),
      read: false,
      description: newDescription || 'Sin descripción ingresada.'
    });

    setToastMessage('¡Nuevo libro añadido con éxito al catálogo!');
    setIsAddModalOpen(false);
    resetForm();
    refreshBooks();
  };

  const resetForm = () => {
    setNewTitle('');
    setNewAuthor('');
    setNewGenre('Ficción');
    setNewRating(5);
    setNewPages(250);
    setNewDescription('');
  };

  const filteredBooks = books.filter(b => {
    const matchesFilter = 
      filter === 'all' ? true :
      filter === 'favorites' ? !!b.favorite :
      filter === 'read' ? b.read : !b.read;
    const matchesSearch = 
      b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (b.genre && b.genre.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesFilter && matchesSearch;
  });

  const sortedBooks = [...filteredBooks].sort((a, b) => {
    if (sortBy === 'title-asc') {
      return a.title.localeCompare(b.title, 'es', { sensitivity: 'base' });
    }
    if (sortBy === 'title-desc') {
      return b.title.localeCompare(a.title, 'es', { sensitivity: 'base' });
    }
    if (sortBy === 'date-desc') {
      const dateA = a.addedAt ? new Date(a.addedAt).getTime() : 0;
      const dateB = b.addedAt ? new Date(b.addedAt).getTime() : 0;
      return dateB - dateA;
    }
    if (sortBy === 'date-asc') {
      const dateA = a.addedAt ? new Date(a.addedAt).getTime() : 0;
      const dateB = b.addedAt ? new Date(b.addedAt).getTime() : 0;
      return dateA - dateB;
    }
    if (sortBy === 'rating-desc') {
      return (b.rating || 0) - (a.rating || 0);
    }
    return 0;
  });

  const readCount = books.filter(b => b.read).length;
  const unreadCount = books.filter(b => !b.read).length;
  const favCount = books.filter(b => b.favorite).length;

  return (
    <div className="flex flex-col min-h-full pb-20">
      <IonHeader>
        <IonToolbar color="primary">
          <IonTitle>📚 Catálogo de Libros</IonTitle>
          <IonButtons slot="end">
            <IonButton fill="clear" color="light" onClick={() => setIsAddModalOpen(true)}>
              <Plus className="w-5 h-5" />
            </IonButton>
          </IonButtons>
        </IonToolbar>

        {/* Stats banner */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white px-4 py-3 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span className="font-medium">Progreso de Lectura:</span>
          </div>
          <div className="flex gap-3 font-semibold">
            <span className="bg-white/20 px-2 py-0.5 rounded-full">Leídos: {readCount}</span>
            <span className="bg-white/20 px-2 py-0.5 rounded-full">Pendientes: {unreadCount}</span>
          </div>
        </div>

        {/* Search bar */}
        <div className="p-3 bg-white border-b border-slate-100">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar por título o autor..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-9 py-2 bg-slate-100 rounded-xl text-sm border-0 focus:outline-hidden focus:ring-2 focus:ring-blue-500/30 text-slate-800 transition-all placeholder:text-slate-400"
              aria-label="Buscar por título o autor"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-200/60 transition-colors"
                title="Limpiar búsqueda"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {searchQuery && (
            <div className="mt-2 px-1 text-[11px] text-slate-500 flex justify-between items-center">
              <span>Coincidencias en tiempo real: <strong className="text-blue-600 font-semibold">{filteredBooks.length}</strong> de {books.length}</span>
              <button 
                onClick={() => setSearchQuery('')}
                className="text-blue-600 hover:underline font-medium text-[11px]"
              >
                Limpiar filtro
              </button>
            </div>
          )}

          <IonSegment value={filter} onIonChange={(v) => setFilter(v as BookFilter)} className="mt-2.5">
            <IonSegmentButton value="all">Todos ({books.length})</IonSegmentButton>
            <IonSegmentButton value="favorites">❤️ Favoritos ({favCount})</IonSegmentButton>
            <IonSegmentButton value="read">Leídos ({readCount})</IonSegmentButton>
            <IonSegmentButton value="unread">Pendientes ({unreadCount})</IonSegmentButton>
          </IonSegment>

          {/* Sorting Dropdown */}
          <div className="flex items-center justify-between gap-2 mt-2.5 pt-2 border-t border-slate-100">
            <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
              <ArrowUpDown className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>Ordenar libros por:</span>
            </div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as BookSortOption)}
              className="bg-slate-100 text-slate-800 text-xs font-semibold py-1.5 px-2.5 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500/30 cursor-pointer outline-none transition-all"
              aria-label="Ordenar libros"
            >
              <option value="date-desc">📅 Más recientes</option>
              <option value="date-asc">📅 Más antiguos</option>
              <option value="title-asc">🔤 Título (A-Z)</option>
              <option value="title-desc">🔤 Título (Z-A)</option>
              <option value="rating-desc">⭐ Mayor valoración</option>
            </select>
          </div>
        </div>
      </IonHeader>

      <div className="p-4 space-y-3 flex-1">
        {filter === 'favorites' && sortedBooks.length > 0 && (
          <div className="bg-rose-50 border border-rose-200/80 rounded-xl p-3 flex items-center justify-between text-xs text-rose-800 shadow-2xs">
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-rose-600 shrink-0" />
              <span>Desliza una tarjeta a la izquierda para <strong>quitar de Favoritos</strong>.</span>
            </div>
            <span className="text-[10px] bg-rose-200/70 text-rose-900 px-2 py-0.5 rounded font-mono font-semibold shrink-0">
              Gestos Tactiles OK
            </span>
          </div>
        )}

        {sortedBooks.length === 0 ? (
          <EmptyState
            type={filter === 'favorites' ? 'favorites' : searchQuery ? 'search' : 'empty'}
            title={filter === 'favorites' ? 'Sin libros favoritos' : searchQuery ? 'Sin coincidencias' : 'Catálogo Vacío'}
            description={filter === 'favorites' ? 'Marca tus libros preferidos con el ícono de corazón.' : searchQuery ? 'No encontramos libros que coincidan con la búsqueda.' : 'Empieza agregando tu primer libro a la biblioteca.'}
            actionLabel="Agregar Libro"
            onAction={() => setIsAddModalOpen(true)}
            className="my-6"
          />
        ) : (
          sortedBooks.map((book) => {
            const isFav = !!book.favorite;
            const handleSwipeAction = () => {
              if (filter === 'favorites' || isFav) {
                const updated = bookService.toggleFavorite(book.id);
                if (updated) {
                  setToastMessage(`"${book.title}" removido de Favoritos.`);
                  refreshBooks();
                }
              } else {
                handleDeleteBook({ stopPropagation: () => {} } as any, book.id, book.title);
              }
            };

            return (
              <SwipeableItem
                key={book.id}
                onDelete={handleSwipeAction}
                deleteLabel={filter === 'favorites' || isFav ? 'Quitar Favorito' : 'Eliminar'}
                deleteIcon={filter === 'favorites' || isFav ? 'heart-off' : 'trash'}
              >
                <IonCard onClick={() => onSelectBook(book.id)} className="m-0 border-0 shadow-none">
                  <div className="p-4 flex gap-3.5 items-start">
                    <div className="relative shrink-0">
                      {book.coverUrl ? (
                        <img 
                          src={book.coverUrl} 
                          alt={book.title} 
                          className="w-16 h-24 object-cover rounded-lg shadow-xs bg-slate-100"
                        />
                      ) : (
                        <div className="w-16 h-24 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center">
                          <Bookmark className="w-8 h-8" />
                        </div>
                      )}
                      <button
                        onClick={(e) => handleToggleFavorite(e, book.id)}
                        className={`absolute -top-2 -right-2 p-1.5 rounded-full backdrop-blur-md transition-all cursor-pointer shadow-sm ${
                          book.favorite 
                            ? 'bg-rose-600 text-white' 
                            : 'bg-white/90 text-slate-400 hover:text-rose-500 border border-slate-200'
                        }`}
                        title={book.favorite ? 'Remover de favoritos' : 'Guardar en favoritos'}
                      >
                        <Heart className={`w-3.5 h-3.5 ${book.favorite ? 'fill-white' : ''}`} />
                      </button>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-bold text-slate-800 text-base leading-tight truncate">{book.title}</h3>
                        <IonBadge color={book.read ? 'success' : 'warning'}>
                          {book.read ? 'Leído' : 'Pendiente'}
                        </IonBadge>
                      </div>

                      <p className="text-xs font-medium text-slate-500 mt-1">Por: {book.author}</p>
                      
                      {book.genre && (
                        <span className="inline-block mt-1 text-[11px] font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md">
                          {book.genre}
                        </span>
                      )}

                      {book.rating && (
                        <div className="mt-2 flex items-center gap-2">
                          <StarRating value={book.rating} readOnly size="sm" />
                          <span className="text-[11px] text-slate-400">({book.rating}/5)</span>
                        </div>
                      )}

                      {/* Reading Progress Bar Pill */}
                      {book.totalPages && (
                        <div className="mt-2 space-y-1">
                          <div className="flex justify-between text-[10px] font-semibold text-slate-500">
                            <span>Progreso: {book.currentPage ?? (book.read ? book.totalPages : 0)}/{book.totalPages} págs</span>
                            <span className="text-blue-600">
                              {Math.min(100, Math.round(((book.currentPage ?? (book.read ? book.totalPages : 0)) / book.totalPages) * 100))}%
                            </span>
                          </div>
                          <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200/50">
                            <div 
                              className={`h-full rounded-full ${
                                book.read 
                                  ? 'bg-emerald-500' 
                                  : 'bg-blue-600'
                              }`}
                              style={{ 
                                width: `${Math.min(100, Math.round(((book.currentPage ?? (book.read ? book.totalPages : 0)) / book.totalPages) * 100))}%` 
                              }}
                            />
                          </div>
                        </div>
                      )}

                      <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2 text-xs">
                        <button
                          onClick={(e) => handleToggleRead(e, book.id)}
                          className={`inline-flex items-center gap-1 font-semibold px-2.5 py-1 rounded-lg transition-colors ${
                            book.read 
                              ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100' 
                              : 'bg-amber-50 text-amber-700 hover:bg-amber-100'
                          }`}
                        >
                          {book.read ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Pendiente
                            </>
                          ) : (
                            <>
                              <Circle className="w-3.5 h-3.5 text-amber-600" /> Marcar Leído
                            </>
                          )}
                        </button>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={(e) => handleToggleFavorite(e, book.id)}
                            className={`p-1.5 rounded-lg transition-colors ${
                              book.favorite 
                                ? 'text-rose-600 bg-rose-50' 
                                : 'text-slate-400 hover:text-rose-600 hover:bg-rose-50'
                            }`}
                            title={book.favorite ? 'Favorito' : 'Marcar favorito'}
                          >
                            <Heart className={`w-4 h-4 ${book.favorite ? 'fill-rose-600' : ''}`} />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectBook(book.id);
                            }}
                            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Ver detalle"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={(e) => handleDeleteBook(e, book.id, book.title)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            title="Eliminar libro"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </IonCard>
              </SwipeableItem>
            );
          })
        )}
      </div>

      {/* Floating Action Button */}
      <IonFab vertical="bottom" horizontal="end">
        <IonFabButton onClick={() => setIsAddModalOpen(true)} color="primary">
          <Plus className="w-6 h-6" />
        </IonFabButton>
      </IonFab>

      {/* Add Book IonModal */}
      <IonModal
        isOpen={isAddModalOpen}
        onDidDismiss={() => setIsAddModalOpen(false)}
        title="Añadir Nuevo Libro"
      >
        <form onSubmit={handleAddBook} className="space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Título del Libro *
            </label>
            <input
              type="text"
              required
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="Ej: Cien Años de Soledad"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Autor *
            </label>
            <input
              type="text"
              required
              value={newAuthor}
              onChange={(e) => setNewAuthor(e.target.value)}
              placeholder="Ej: Gabriel García Márquez"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
                Género
              </label>
              <select
                value={newGenre}
                onChange={(e) => setNewGenre(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
              >
                <option value="Ficción">Ficción</option>
                <option value="Realismo Mágico">Realismo Mágico</option>
                <option value="Ciencia Ficción">Ciencia Ficción</option>
                <option value="Filosofía">Filosofía</option>
                <option value="Historia">Historia</option>
                <option value="Desarrollo Personal">Desarrollo Personal</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
                Páginas
              </label>
              <input
                type="number"
                min="10"
                value={newPages}
                onChange={(e) => setNewPages(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Valoración Personal (1-5)
            </label>
            <StarRating value={newRating} onChange={setNewRating} size="lg" />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1">
              Sinopsis / Descripción
            </label>
            <textarea
              rows={3}
              value={newDescription}
              onChange={(e) => setNewDescription(e.target.value)}
              placeholder="Resumen del libro o notas de lectura..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/30"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
            <IonButton fill="clear" color="medium" onClick={() => setIsAddModalOpen(false)}>
              Cancelar
            </IonButton>
            <IonButton type="submit" color="primary">
              Guardar Libro
            </IonButton>
          </div>
        </form>
      </IonModal>

      {/* Toast Notification */}
      <IonToast
        isOpen={!!toastMessage}
        message={toastMessage || ''}
        onDidDismiss={() => setToastMessage(null)}
      />
    </div>
  );
};
