import { Recipe, RecipeCategoryFilter } from '../models/recipe.model';
import { syncService } from './sync.service';

const STORAGE_KEY = 'academic_recipes_db_v1';

const INITIAL_RECIPES: Recipe[] = [
  {
    id: 'recipe-1',
    name: 'Chilaquiles Verdes con Pollo',
    title: 'Chilaquiles Verdes con Pollo',
    category: 'Desayunos',
    minutes: 25,
    prepTime: 25,
    favorite: true,
    isFavorite: true,
    ingredients: [
      '12 tortillas de maíz cortadas en triángulos',
      '500g de tomate verde (tomatillo)',
      '2 chiles serranos',
      '1 diente de ajo',
      '1/4 de cebolla blanca',
      '200g de pechuga de pollo deshebrada',
      'Crema ácida, queso fresco y cebolla morada para decorar'
    ],
    instructions: [
      'Freír las tortillas en aceite caliente hasta que estén crujientes y doradas. Reservar sobre papel absorbente.',
      'Hervir los tomates verdes y chiles serranos en agua durante 8 minutos.',
      'Licuar los tomates, chiles, ajo, cebolla y un toque de cilantro con sal al gusto.',
      'Sazonar la salsa verde en una sartén profunda con una cucharadita de aceite durante 5 minutos.',
      'Incorporar los totopos crujientes a la salsa hirviendo, mezclar suavemente y servir de inmediato.',
      'Corona con el pollo deshebrado, crema fresca, queso desmoronado y aros de cebolla.'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1599974579688-8dbdd335c77f?auto=format&fit=crop&w=800&q=80',
    difficulty: 'Fácil',
    calories: 420,
    servings: 4,
    createdAt: new Date(2025, 1, 12).toISOString()
  },
  {
    id: 'recipe-2',
    name: 'Tacos Al Pastor Caseros',
    title: 'Tacos Al Pastor Caseros',
    category: 'Almuerzos',
    minutes: 45,
    prepTime: 45,
    favorite: true,
    isFavorite: true,
    ingredients: [
      '800g de lomo de cerdo cortado en tiras delgadas',
      '3 chiles guajillo hidratados',
      '1 chile ancho hidratado',
      '1/4 taza de jugo de naranja',
      '2 cucharadas de pasta de achiote',
      '1/2 taza de piña fresca picada',
      'Tortillas de maíz pequeñas',
      'Cilantro, cebolla picada y limones'
    ],
    instructions: [
      'Licuar chiles guajillo, chile ancho, achiote, jugo de naranja, vinagre y especias hasta obtener un adobo homógéneo.',
      'Marinar la carne de cerdo con el adobo durante al menos 2 horas en refrigeración.',
      'Cocinar la carne marinated en una sartén muy caliente con un poco de aceite hasta dorar sus orillas.',
      'Servir caliente sobre tortillas recién hechas, acompañar con piña asada, cebolla, cilantro y sal.'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?auto=format&fit=crop&w=800&q=80',
    difficulty: 'Media',
    calories: 550,
    servings: 6,
    createdAt: new Date(2025, 2, 5).toISOString()
  },
  {
    id: 'recipe-3',
    name: 'Ensalada César con Pollo a las Hierbas',
    title: 'Ensalada César con Pollo a las Hierbas',
    category: 'Cenas',
    minutes: 20,
    prepTime: 20,
    favorite: false,
    isFavorite: false,
    ingredients: [
      '2 tazas de lechuga orejona fresca desinfectada',
      '250g de pechuga de pollo a la plancha',
      '1/2 taza de crotones de pan de ajo',
      '1/3 taza de queso parmesano rallado',
      '3 cucharadas de aderezo César artesanal',
      'Pimienta negra recién molida'
    ],
    instructions: [
      'Cortar la lechuga en trozos medianos y colocar en un tazón amplio.',
      'Asar la pechuga de pollo sazonada con orégano, tomillo, sal y pimienta. Cortar en tiras.',
      'Mezclar la lechuga con el aderezo César hasta cubrir uniformemente.',
      'Servir con las tiras de pollo caliente, crotones crujientes y abundante queso parmesano.'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80',
    difficulty: 'Fácil',
    calories: 310,
    servings: 2,
    createdAt: new Date(2025, 2, 18).toISOString()
  },
  {
    id: 'recipe-4',
    name: 'Volcán de Chocolate con Nieve de Vainilla',
    title: 'Volcán de Chocolate con Nieve de Vainilla',
    category: 'Postres',
    minutes: 30,
    prepTime: 30,
    favorite: true,
    isFavorite: true,
    ingredients: [
      '150g de chocolate amargo 70%',
      '100g de mantequilla sin sal',
      '3 huevos enteros',
      '50g de azúcar refinada',
      '40g de harina de trigo cernida',
      'Helado de vainilla para acompañar'
    ],
    instructions: [
      'Derretir el chocolate junto con la mantequilla a baño María hasta obtener un brillo uniforme.',
      'Batir los huevos con el azúcar hasta que blanqueen y dupliquen su volumen.',
      'Incorporar la harina con movimientos envolventes y añadir la mezcla de chocolate.',
      'Verter en moldes individuales engrasados con mantequilla y cocoa en polvo.',
      'Hornear a 200°C por exactamente 10 a 12 minutos (el centro debe permanecer líquido).',
      'Desmoldar con cuidado y servir de inmediato con una bola de helado de vainilla.'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=800&q=80',
    difficulty: 'Avanzada',
    calories: 480,
    servings: 4,
    createdAt: new Date(2025, 3, 1).toISOString()
  }
];

class RecipeService {
  private recipes: Recipe[] = [];

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        this.recipes = JSON.parse(stored);
      } else {
        this.recipes = [...INITIAL_RECIPES];
        this.saveToStorage();
      }
    } catch {
      this.recipes = [...INITIAL_RECIPES];
    }
  }

  private saveToStorage(entityName: string = 'Receta') {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.recipes));
      syncService.notifySyncing(entityName);
    } catch (e) {
      console.error('Error saving recipes to storage', e);
    }
  }

  getAll(): Recipe[] {
    return [...this.recipes];
  }

  getById(id: string): Recipe | undefined {
    return this.recipes.find(r => r.id === id);
  }

  getFavorites(): Recipe[] {
    return this.recipes.filter(r => r.favorite || r.isFavorite);
  }

  toggleFavorite(id: string): Recipe | undefined {
    const recipe = this.recipes.find(r => r.id === id);
    if (recipe) {
      const newFav = !(recipe.favorite ?? recipe.isFavorite);
      recipe.favorite = newFav;
      recipe.isFavorite = newFav;
      this.saveToStorage();
    }
    return recipe;
  }

  add(recipeData: Omit<Recipe, 'id' | 'createdAt'>): Recipe {
    const nameVal = recipeData.name || recipeData.title || 'Nueva Receta';
    const minutesVal = recipeData.minutes ?? recipeData.prepTime ?? 15;
    const isFav = recipeData.favorite ?? recipeData.isFavorite ?? false;

    const newRecipe: Recipe = {
      ...recipeData,
      name: nameVal,
      title: nameVal,
      minutes: minutesVal,
      prepTime: minutesVal,
      favorite: isFav,
      isFavorite: isFav,
      id: `recipe-${Date.now()}`,
      createdAt: new Date().toISOString(),
      imageUrl: recipeData.imageUrl || 'https://images.unsplash.com/photo-1495521821757-a1efb6729352?auto=format&fit=crop&w=800&q=80'
    };
    this.recipes.unshift(newRecipe);
    this.saveToStorage();
    return newRecipe;
  }

  delete(id: string): boolean {
    const initialLength = this.recipes.length;
    this.recipes = this.recipes.filter(r => r.id !== id);
    if (this.recipes.length !== initialLength) {
      this.saveToStorage();
      return true;
    }
    return false;
  }

  getByCategory(category: RecipeCategoryFilter): Recipe[] {
    if (category === 'Todas') return this.getAll();
    if (category === 'Favoritas') return this.getFavorites();
    return this.recipes.filter(r => r.category === category);
  }

  resetToDefaults(): void {
    this.recipes = [...INITIAL_RECIPES];
    this.saveToStorage();
  }
}

export const recipeService = new RecipeService();
