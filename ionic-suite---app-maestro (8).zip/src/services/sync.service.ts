import { useState, useEffect } from 'react';

export type SyncState = 'idle' | 'syncing' | 'saved' | 'error';

export interface SyncNotification {
  state: SyncState;
  message?: string;
  timestamp: number;
}

type SyncListener = (notification: SyncNotification) => void;

class SyncService {
  private listeners: Set<SyncListener> = new Set();
  private currentNotification: SyncNotification = {
    state: 'idle',
    timestamp: Date.now()
  };
  private timer: NodeJS.Timeout | null = null;

  subscribe(listener: SyncListener) {
    this.listeners.add(listener);
    listener(this.currentNotification);
    return () => {
      this.listeners.delete(listener);
    };
  }

  notifySyncing(entityName?: string) {
    if (this.timer) clearTimeout(this.timer);

    this.currentNotification = {
      state: 'syncing',
      message: entityName ? `Sincronizando ${entityName}...` : 'Guardando cambios...',
      timestamp: Date.now()
    };
    this.emit();

    // Simulate service sync / indexed storage delay
    this.timer = setTimeout(() => {
      this.currentNotification = {
        state: 'saved',
        message: entityName ? `${entityName} guardado correctamente` : 'Cambios guardados',
        timestamp: Date.now()
      };
      this.emit();

      this.timer = setTimeout(() => {
        this.currentNotification = {
          state: 'idle',
          timestamp: Date.now()
        };
        this.emit();
      }, 2400);
    }, 400);
  }

  getCurrentState(): SyncNotification {
    return this.currentNotification;
  }

  private emit() {
    this.listeners.forEach(listener => listener(this.currentNotification));
  }
}

export const syncService = new SyncService();

export function useSyncStatus() {
  const [status, setStatus] = useState<SyncNotification>(() => syncService.getCurrentState());

  useEffect(() => {
    const unsubscribe = syncService.subscribe((newStatus) => {
      setStatus(newStatus);
    });
    return unsubscribe;
  }, []);

  return status;
}
