import React, { useState } from 'react';
import { MobileFrame, ActiveProject } from './components/shared/MobileFrame';
import { ErrorBoundary } from './components/shared/ErrorBoundary';

// Page Views
import { BooksHomePage } from './pages/books/BooksHomePage';
import { BookDetailPage } from './pages/books/BookDetailPage';

import { RestaurantsHomePage } from './pages/restaurants/RestaurantsHomePage';

import { RecipesHomePage } from './pages/recipes/RecipesHomePage';
import { RecipeDetailPage } from './pages/recipes/RecipeDetailPage';

import { SuggestionsHomePage } from './pages/suggestions/SuggestionsHomePage';

// Services for resetting
import { bookService } from './services/book.service';
import { restaurantService } from './services/restaurant.service';
import { recipeService } from './services/recipe.service';
import { suggestionService } from './services/suggestion.service';

export default function App() {
  const [activeProject, setActiveProject] = useState<ActiveProject>('books');

  // Sub-navigation state
  const [selectedBookId, setSelectedBookId] = useState<string | null>(null);
  const [selectedRecipeId, setSelectedRecipeId] = useState<string | null>(null);

  const handleResetAll = () => {
    if (window.confirm('¿Restablecer los datos iniciales de todos los proyectos?')) {
      bookService.resetToDefaults();
      restaurantService.resetToDefaults();
      recipeService.resetToDefaults();
      suggestionService.resetToDefaults();
      setSelectedBookId(null);
      setSelectedRecipeId(null);
      window.location.reload();
    }
  };

  const handleSelectProject = (project: ActiveProject) => {
    setActiveProject(project);
    setSelectedBookId(null);
    setSelectedRecipeId(null);
  };

  return (
    <MobileFrame
      activeProject={activeProject}
      setActiveProject={handleSelectProject}
      onResetAll={handleResetAll}
    >
      <ErrorBoundary key={activeProject}>
        {/* PROYECTO 1: CATÁLOGO DE LIBROS */}
        {activeProject === 'books' && (
          selectedBookId ? (
            <BookDetailPage 
              bookId={selectedBookId} 
              onBack={() => setSelectedBookId(null)} 
            />
          ) : (
            <BooksHomePage 
              onSelectBook={(id) => setSelectedBookId(id)} 
            />
          )
        )}

        {/* PROYECTO 2: CATÁLOGO DE RESTAURANTES */}
        {activeProject === 'restaurants' && (
          <RestaurantsHomePage />
        )}

        {/* PROYECTO 3: CATÁLOGO DE RECETAS */}
        {activeProject === 'recipes' && (
          selectedRecipeId ? (
            <RecipeDetailPage 
              recipeId={selectedRecipeId} 
              onBack={() => setSelectedRecipeId(null)} 
            />
          ) : (
            <RecipesHomePage 
              onSelectRecipe={(id) => setSelectedRecipeId(id)} 
            />
          )
        )}

        {/* PROYECTO 4: BUZÓN DE SUGERENCIAS */}
        {activeProject === 'suggestions' && (
          <SuggestionsHomePage />
        )}
      </ErrorBoundary>
    </MobileFrame>
  );
}
