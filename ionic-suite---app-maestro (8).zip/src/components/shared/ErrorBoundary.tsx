import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

export interface ErrorBoundaryProps {
  children?: ReactNode;
  fallback?: ReactNode;
  onReset?: () => void;
}

export interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('ErrorBoundary capturó un error:', error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
    if (this.props.onReset) {
      this.props.onReset();
    }
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="flex flex-col items-center justify-center p-8 text-center min-h-[300px] my-auto bg-white/80 backdrop-blur-sm rounded-2xl border border-rose-100 shadow-sm m-4">
          <div className="w-16 h-16 rounded-2xl bg-rose-50 flex items-center justify-center border border-rose-100 mb-4 shadow-xs text-rose-500">
            <AlertTriangle className="w-8 h-8" />
          </div>

          <h2 className="text-lg font-bold text-slate-900 mb-1">
            Algo salió mal al cargar esta vista
          </h2>

          <p className="text-xs text-slate-500 max-w-sm mb-6 leading-relaxed">
            Se ha producido un error inesperado al renderizar los componentes. Puedes reintentar o restablecer el estado.
          </p>

          {this.state.error && (
            <div className="mb-6 p-3 bg-slate-50 border border-slate-200 rounded-xl text-left w-full max-w-md overflow-x-auto">
              <p className="text-[11px] font-mono text-rose-600 font-semibold truncate">
                {this.state.error.toString()}
              </p>
            </div>
          )}

          <button
            onClick={this.handleReset}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-sm transition-all hover:shadow cursor-pointer active:scale-95 flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            Reintentar y Recargar Vista
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
