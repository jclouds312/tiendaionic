import React, { useState, useRef } from 'react';
import { Trash2, Heart, HeartOff } from 'lucide-react';

interface SwipeableItemProps {
  children: React.ReactNode;
  onDelete: () => void;
  deleteLabel?: string;
  deleteIcon?: 'trash' | 'heart-off';
  confirmMessage?: string;
  className?: string;
  disabled?: boolean;
}

export const SwipeableItem: React.FC<SwipeableItemProps> = ({
  children,
  onDelete,
  deleteLabel = 'Quitar Favorito',
  deleteIcon = 'heart-off',
  className = '',
  disabled = false
}) => {
  const [translateX, setTranslateX] = useState(0);
  const [isSwiping, setIsSwiping] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const startXRef = useRef<number>(0);
  const currentXRef = useRef<number>(0);

  const ACTION_WIDTH = 100; // Width of revealed action button in px
  const SWIPE_THRESHOLD = 180; // Full swipe trigger threshold

  // Touch Handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    if (disabled) return;
    startXRef.current = e.touches[0].clientX;
    currentXRef.current = e.touches[0].clientX;
    setIsSwiping(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isSwiping || disabled) return;
    currentXRef.current = e.touches[0].clientX;
    const diffX = currentXRef.current - startXRef.current;

    // We only care about dragging left (negative diffX)
    if (isOpen) {
      // Starting from open position (-ACTION_WIDTH)
      const newX = -ACTION_WIDTH + diffX;
      setTranslateX(Math.min(20, Math.max(-SWIPE_THRESHOLD - 30, newX)));
    } else {
      // Starting from closed position (0)
      if (diffX < 0) {
        setTranslateX(Math.max(-SWIPE_THRESHOLD - 30, diffX));
      } else {
        setTranslateX(Math.min(20, diffX));
      }
    }
  };

  const handleTouchEnd = () => {
    if (!isSwiping || disabled) return;
    setIsSwiping(false);

    // Check if swiped far enough to auto-delete
    if (translateX < -SWIPE_THRESHOLD) {
      setTranslateX(-300);
      setTimeout(() => {
        onDelete();
        setTranslateX(0);
        setIsOpen(false);
      }, 200);
      return;
    }

    // Check if swiped enough to snap open
    if (translateX < -40) {
      setTranslateX(-ACTION_WIDTH);
      setIsOpen(true);
    } else {
      setTranslateX(0);
      setIsOpen(false);
    }
  };

  // Mouse Handlers for Desktop testing
  const handleMouseDown = (e: React.MouseEvent) => {
    if (disabled) return;
    startXRef.current = e.clientX;
    currentXRef.current = e.clientX;
    setIsSwiping(true);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isSwiping || disabled) return;
    currentXRef.current = e.clientX;
    const diffX = currentXRef.current - startXRef.current;

    if (isOpen) {
      const newX = -ACTION_WIDTH + diffX;
      setTranslateX(Math.min(20, Math.max(-SWIPE_THRESHOLD - 30, newX)));
    } else {
      if (diffX < 0) {
        setTranslateX(Math.max(-SWIPE_THRESHOLD - 30, diffX));
      } else {
        setTranslateX(Math.min(20, diffX));
      }
    }
  };

  const handleMouseUp = () => {
    if (!isSwiping || disabled) return;
    setIsSwiping(false);

    if (translateX < -SWIPE_THRESHOLD) {
      setTranslateX(-300);
      setTimeout(() => {
        onDelete();
        setTranslateX(0);
        setIsOpen(false);
      }, 200);
      return;
    }

    if (translateX < -40) {
      setTranslateX(-ACTION_WIDTH);
      setIsOpen(true);
    } else {
      setTranslateX(0);
      setIsOpen(false);
    }
  };

  const handleMouseLeave = () => {
    if (isSwiping) {
      handleMouseUp();
    }
  };

  const handleActionClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setTranslateX(-300);
    setTimeout(() => {
      onDelete();
      setTranslateX(0);
      setIsOpen(false);
    }, 150);
  };

  return (
    <div className={`relative overflow-hidden rounded-2xl select-none ${className}`}>
      {/* Background Action Button (Revealed on swipe) */}
      <div 
        className="absolute inset-y-0 right-0 flex items-center justify-end bg-rose-600 text-white rounded-r-2xl z-0"
        style={{ width: `${ACTION_WIDTH + 20}px` }}
      >
        <button
          onClick={handleActionClick}
          className="h-full w-full flex flex-col items-center justify-center gap-1 bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white px-3 transition-colors cursor-pointer"
          title={deleteLabel}
        >
          {deleteIcon === 'trash' ? (
            <Trash2 className="w-5 h-5 text-white animate-bounce" />
          ) : (
            <HeartOff className="w-5 h-5 text-white animate-bounce" />
          )}
          <span className="text-[10px] font-bold uppercase tracking-wider text-center leading-tight">
            {deleteLabel}
          </span>
        </button>
      </div>

      {/* Foreground Content Card */}
      <div
        style={{
          transform: `translateX(${translateX}px)`,
          transition: isSwiping ? 'none' : 'transform 0.25s cubic-bezier(0.2, 0.8, 0.2, 1)'
        }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseLeave}
        className="relative z-10 bg-white"
      >
        {children}
      </div>
    </div>
  );
};
