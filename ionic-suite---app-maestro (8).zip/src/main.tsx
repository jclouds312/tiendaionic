import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import './theme/ionic-theme.css';
import { registerServiceWorker } from './serviceWorkerRegistration';

// Register Service Worker for offline persistence across Libros, Recetas y Restaurantes
registerServiceWorker();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

