const CACHE_NAME = 'academic-catalog-pwa-v1';
const DYNAMIC_CACHE = 'academic-catalog-dynamic-v1';

// App shell and static fallback resources
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json'
];

// Installation phase: Pre-cache core app shell
self.addEventListener('install', (event) => {
  console.log('[Service Worker] Installing SW & pre-caching App Shell');
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS).catch((err) => {
        console.warn('[Service Worker] Static pre-cache warning:', err);
      });
    }).then(() => self.skipWaiting())
  );
});

// Activation phase: Clean up outdated caches
self.addEventListener('activate', (event) => {
  console.log('[Service Worker] Activating SW & cleaning old caches');
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME && key !== DYNAMIC_CACHE) {
            console.log('[Service Worker] Removing old cache:', key);
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch event interceptor
self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // Skip non-GET requests
  if (req.method !== 'GET') return;

  // Strategy 1: External Images (Unsplash, CDN covers/photos) -> Cache First with Network Fallback
  if (req.destination === 'image' || url.hostname.includes('unsplash.com') || url.pathname.match(/\.(png|jpg|jpeg|svg|webp|gif|ico)$/i)) {
    event.respondWith(
      caches.match(req).then((cachedResponse) => {
        if (cachedResponse) {
          // Revalidate in background
          fetch(req).then((networkResponse) => {
            if (networkResponse && networkResponse.ok) {
              caches.open(DYNAMIC_CACHE).then((cache) => cache.put(req, networkResponse));
            }
          }).catch(() => {/* Silent catch offline fallback */});
          return cachedResponse;
        }

        return fetch(req)
          .then((networkResponse) => {
            if (!networkResponse || !networkResponse.ok) return networkResponse;
            const responseClone = networkResponse.clone();
            caches.open(DYNAMIC_CACHE).then((cache) => cache.put(req, responseClone));
            return networkResponse;
          })
          .catch(() => {
            // Return empty transparent SVG placeholder if image fails completely offline
            return new Response(
              '<svg xmlns="http://www.w3.org/2000/svg" width="300" height="200" viewBox="0 0 300 200"><rect width="100%" height="100%" fill="#e2e8f0"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#64748b" font-family="sans-serif" font-size="14">Modo Offline - Imagen Cacheada</text></svg>',
              { headers: { 'Content-Type': 'image/svg+xml' } }
            );
          });
      })
    );
    return;
  }

  // Strategy 2: Navigation & HTML / App Shell -> Network First with Cache Fallback
  if (req.mode === 'navigate' || req.destination === 'document') {
    event.respondWith(
      fetch(req)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.ok) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(req, responseClone));
          }
          return networkResponse;
        })
        .catch(() => {
          return caches.match(req).then((cachedResponse) => {
            if (cachedResponse) return cachedResponse;
            return caches.match('/index.html') || caches.match('/');
          });
        })
    );
    return;
  }

  // Strategy 3: Scripts, Styles, Fonts -> Stale While Revalidate
  event.respondWith(
    caches.match(req).then((cachedResponse) => {
      const fetchPromise = fetch(req)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.ok) {
            const responseClone = networkResponse.clone();
            caches.open(DYNAMIC_CACHE).then((cache) => cache.put(req, responseClone));
          }
          return networkResponse;
        })
        .catch(() => cachedResponse);

      return cachedResponse || fetchPromise;
    })
  );
});

// Listener for custom postMessages (e.g., skipWaiting or cache purging)
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
